
//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//


//
// CVS Information
//
// $Author: graceej $ $Date: 2009/07/20 18:34:40 $
// $Revision
//

/**
 * @file   example_timer.cpp
 * @author Edward Grace <edward.grace@imperial.ac.uk>
 * @date   Sat Jul 18 13:43:16 BST 2009
 * 
 * @brief An example of how to use the generic timer class in its to
 *        time two functions that should differ in run-time by around
 *        0.5%.
 *
 *        In order to observe the difference the initial requested
 *        precision (50%) will be inadequate and the timer will be
 *        called repeatedly with increasing precision until a
 *        difference can be reliably observed.
 *
 *        You my find it informative to compile this with different
 *        levels of optimisation and with the -DNDEBUG compiler
 *        directive defined. 
 *
 *        Although the expected difference between function_fast() and
 *        function_slow() is 0.5% you may observe differences due to
 *        the compiler options yielding anything from 0.1% to 2%
 *        nominal speedups.  Of course the compiler switches affect
 *        the timer code as well as function_slow() and
 *        function_fast() so one cannot fully infer what the effect of
 *        changing compiler options is on the test functions.
 */
#include <ejg/timer.hpp>
#include <iostream>

#include "cycle.h"

// Non-standard header for gettimeofday on *NIX
//#include <sys/time.h> 

/** 
 * @brief The 'slow' function.
 */
void function_slow(); 

/** 
 * @brief The 'fast' function.
 */
void function_fast();


int main(void) {

  
  /* Make a timing object that uses the microsecond timer clock. */
  ejg::generic_timer<ticks> t(getticks,elapsed);

  /* Alternatively you could use the default std::clock() based
     timer. */
  //ejg::crude_timer t;

  
  double MinPercent,MedPercent,MaxPercent;
  bool is_able_to_discriminate(false);
  
  std::cout << "Calibrating the clock, for a slow timer this may take a while!\n";

  /* Calibrate the overhead in calling the chronometer, also estimate
     how precise the timer *really* is. Often we think that the timer
     is only good for one clock tick, this minimum quantum of time
     must also be considered along with any other jitter that we don't
     obviously know about. 

     For slow clocks, where the overhead in calling the clock - and
     the jitter on this overhead is small compared to the function
     under test this can safely be ignored.
  */
  t.calibrate_chrono_overhead();
  std::cout << "Point estimate of clock overhead (t_c): " 
	    << t.get_chrono_overhead() << std::endl; 
  std::cout << "Potential jitter on t_c (sigma_c)     : " 
	    << t.get_chrono_sigma() << std::endl;
  

  std::cout << "Increasing precision until I can discriminate between function a and b.\n";
  std::cout << "The nominal confidence interval (minimum, [median], maximum) represents the region: 1-alpha=" 
	    << 1.0-t.get_alpha_percentage_speedup() << std::endl;
  
  /* Start by assuming a nominal +/- 50.0% precision in the acquired
     times. At each attempt halve the nominal precision and re-time
     the functions. Once we can discriminate between them, stop.*/
  double nominal_precision(50.0);
  unsigned remaining_attempts(5);
  for (; remaining_attempts && !is_able_to_discriminate; 
       --remaining_attempts, nominal_precision *= 0.2) {

    /* Set the nominal precision of the timer.  This is not the
       actual precision; it dictates the number of iterations that
       must be run in a timing loop so that the clock jitter has an
       effect smaller than the requested nominal precision. 

       Similarly do not confuse this with the requirement to detect a
       given percentage speedup.  You can often reliably detect a
       small difference in speed (5%) with a much larger nominal
       precision (say 15%) however you may have quite a large
       confidence interval.
    */
    t.set_nominal_precision_target_percent(nominal_precision);

    std::cout << "Timing at a nominal precision of " 
	      << t.get_nominal_precision_target_percent() << "%:";

    /* Time the speedup of function a with respect to function b,
       returning the (default) 95% confidence intervals for this
       speedup and the estimate of the median in the return values.

       If the range of percentage speedup includes zero or is not a
       number (undefined) then we can't say that the two functions
       differ in speed.

       If the upper and lower bounds are wildly asymmetric with
       respect to the median, for example, [-50,10,10.1] this is
       indicative of a process significantly affecting one of the
       measurements in the Wilcoxon signed rank test.  Again, this is
       not a bug, the returned confidence bounds indicate that from
       these measurements you cannot decide if a is faster or slower
       than b within this confidence interval. 
       
       In practice this wild discrepancy would be flagged up and
       retested - but you did not make the mistake from a point
       estimate, of thinking a was 50% slower than b, when in fact it
       may be 0% faster!
    */
    t.measure_percentage_speedup(function_fast,
				 function_slow,
				 MinPercent,
				 MedPercent,
				 MaxPercent);
    
    /* We now test to see if the confidence interval straddles zero,
       or is NaN. We cannot discriminate between the functions if the
       range includes zero. */
    is_able_to_discriminate = ( MinPercent == MinPercent && MaxPercent == MaxPercent) && 
      !(MinPercent <= 0.0 && MaxPercent >= 0.0);

    if (is_able_to_discriminate)
      std::cout <<  " A is " << ((MedPercent > 0.0) ? "faster" : "slower") << " than B by: ";
    else 
      std::cout << " We cannot distinguish between A and B: ";
    
    std::cout << " (" << MinPercent << " [" << MedPercent << "] " << MaxPercent << ")%\n";
  }
  std::cout << std::endl;
  return 0;
}


/** 
 * Global variables used by the trivial kernel to prevent removal
 * through optimisation of what we wish to time
 */
unsigned sum(0);
unsigned prod(1);

/** 
 * @brief This is the simple kernel we wish to time. 
 * 
 * @param trivial_kernel_count The number of iterations of the loop.
 */
inline void trivial_kernel(unsigned trivial_kernel_count) {
  /* This prevents the optimizer skipping the loop as it forces side
     effects. */
  sum = 0; prod = 1;
  for (unsigned n(0); n != trivial_kernel_count; ++n) {
    sum += n; prod *= n/100;
  }
}

inline void function_fast() {
  trivial_kernel(1000); /* Should be around 0.5% faster than b. */
}
inline void function_slow() {
  trivial_kernel(1005); 
}

//
// $Log: example_timer.cpp,v $
// Revision 1.2.2.3  2009/07/20 18:34:40  graceej
// * Modified to avoid needing a striding iterator.
// * Copy is now done the ugly way.
//
// Revision 1.2.2.2  2009/07/20 14:18:05  graceej
// * Modifications to compile under MSVC
//
// Revision 1.2.2.1  2009/07/20 11:35:23  graceej
// * Build is clean on OS X and generates documentation.
//
// Revision 1.2  2009/07/19 17:46:06  graceej
// * Corrected warning raised -ansi -pedantic.
//
// Revision 1.1  2009/07/18 19:48:07  graceej
// * Moved the examples somewhere sane.
//
// Revision 1.4  2009/07/18 18:59:39  graceej
// * Explicitly include sys/time.h for gettimeofday().
//
// Revision 1.3  2009/07/18 18:56:47  graceej
// * Avoided the optimization of the loop by forcing side-effect.
//
// Revision 1.2  2009/07/18 14:26:55  graceej
// * Weeded the code to smarten up its layout and remove unwanted functions.
// * Brought over these changes to the HEAD branch.
// * Prepare for upload of timer to boost vault.
//
// Revision 1.1.2.3  2009/07/18 14:25:31  graceej
// * Ready for upload to boost Vault.
//
// Revision 1.1.2.2  2009/07/18 13:58:21  graceej
// * Updated documentation for example_timer.cpp
//
//
