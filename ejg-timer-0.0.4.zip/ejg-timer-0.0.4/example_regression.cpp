
//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//


//
// CVS Information
//
// $Author: graceej $ $Date: 2009/07/20 11:37:52 $
// $Revision
//

/**
 * @file   example_regression.cpp
 * @author Edward Grace <edward.grace@imperial.ac.uk>
 * @date   
 * 
 * @brief An example using the linear_regression_estimate function to
 *        estimate the run time of a given function.
 */
#include <ejg/timer.hpp>
#include <iostream>


#include "cycle.h"

inline void trivial_kernel(unsigned trivial_kernel_count) {
  unsigned  sum(0),prod(1);
  for (unsigned n(0); n != trivial_kernel_count; ++n) {
    sum += n; prod *= n/100;
  }
}

inline void a() {
  trivial_kernel(1000);
}

int main() {

  // Construct a timer from getticks.
  ejg::generic_timer<ticks> t(getticks,elapsed);
  //ejg::generic_timer<> t;
  double slope,offset,mad;
  t.set_nominal_precision_target_percent(1);
  t.calibrate_chrono_overhead();
  t.calibrate_seconds();
  t.measure_infinity_time(a,slope,offset,mad);
  std::cout << t.microseconds(slope) << "+/-" << t.get_nominal_precision_target_percent()*t.microseconds(slope)/100.0 << " microseconds" << std::endl;
  return 0;
}
