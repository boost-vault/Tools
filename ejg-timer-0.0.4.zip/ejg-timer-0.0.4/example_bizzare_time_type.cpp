
//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//


//
// CVS Information
//
// $Author: graceej $ $Date: 2009/07/20 11:39:12 $
// $Revision
//

/**
 * @file   example_bizzare_time_type.cpp
 * @author Edward Grace <edward.grace@imperial.ac.uk>
 * @date   
 * 
 * @brief An example demonstrating how to shoe-horn a bizzare timer
 * type that may be returned by some platforms (e.g. getticks() on
 * Windows).
 */
#include <ejg/timer.hpp>
#include <iostream>
#include <string> /* For bizzare_time_type */

struct bizzare_time_type {
  double the_time;
  std::string _dummy;		/**< Yes, a string!  So what? */
  /* We must make sure that initialising the time type to a given
     integer (usually zero) makes sense. */
  /** 
   * @brief We must make sure that initialising the time type to a
   * given integer (usually zero) makes sense.
   * 
   * @param initial The value to which we should initialise.
   */  
  bizzare_time_type(int initial=0) : the_time(initial) {}
};

/** 
 * @brief This is a chronometer that returns a bizzare time type.
 * Note that actually it's just a call to clock.
 * 
 * 
 * @return A bizzare structure containing a time.
 */
bizzare_time_type bizzare_chrono() {
  bizzare_time_type t;
  t.the_time = std::clock();
  return t;
}

/** 
 * @brief Take the difference of two bizzare times and return a sane
 * value (a double).
 * 
 * @param t1 The first time.
 * @param t0 The zero (start) time.
 * 
 * @return Notionally t1 - t0.
 */
ejg::ticks::difference_type 
bizzare_chrono_difference(bizzare_time_type t1, 
			  bizzare_time_type t0) {
  return ejg::ticks::difference_type(t1.the_time - t0.the_time);
}


inline void trivial_kernel(unsigned trivial_kernel_count) {
  unsigned  sum(0),prod(1);
  for (unsigned n(0); n != trivial_kernel_count; ++n) {
    sum += n; prod *= n/100;
  }
}

inline void a() {
  trivial_kernel(1000);
}

int main() {
  /* Construct a timer using the bizzare chronometer above and a
     function to give the difference between two timestamps returned
     by the bizarre chronometer. */
  ejg::generic_timer<bizzare_time_type> t(bizzare_chrono,
					  bizzare_chrono_difference);

  /* Do something trivial with the timer. */
  t.calibrate_chrono_overhead();
  std::cout << "t_c:   " << t.get_chrono_overhead() << std::endl;
  std::cout << "sigma: " << t.get_chrono_sigma() << std::endl;
  return 0;
}
