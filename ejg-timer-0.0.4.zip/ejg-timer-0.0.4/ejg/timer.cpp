

//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//
#include <iostream>
//
// CVS Information.
//
// $Author: graceej $ $Date: 2009/07/20 19:01:26 $
// $Revision: 1.6.2.3 $
//

#include <ejg/statistics/statistics.hpp>
#ifdef _EJG_USE_STRIDING_ITERATOR_
#include <ejg/striding_iterator.hpp>
#endif
#include <algorithm>
#include <cassert>
#include <limits>
#include <numeric>

//
// For 'special' platforms.  You know who you are William!
//
#ifdef max
#undef max
#endif
#ifdef min
#undef min
#endif

namespace ejg { 

  template <typename ticks, typename ticks_wall>
  generic_timer<ticks,ticks_wall>::
  generic_timer(const fast_chrono_function_type &high_precision, 
		const fast_chrono_difference_function_type &high_precision_difference,
		const wall_chrono_function_type &low_precision, 
		ticks_wall clocks_per_sec) :
    chrono(high_precision),
    chrono_difference(high_precision_difference),
    chrono_wall(low_precision),
    chrono_wall_scale(clocks_per_sec),
    chrono_scale(0),
    alpha(0.05),
    t_a(ejg::statistics::wilcoxon::min_sample_size(alpha)+1), // 6
    t_b(t_a.size()),
    z(t_a.size()),
    batch(4),
    xs(100*batch),
    ys(100*batch),
    residuals(100*batch),
    tmp(100*batch),
    calibration_loop_count(3),
    alpha_d(0.05),
    max_time_seconds(1.0), // A sensible length of time to wait.
    nominal_precision_target(10.0), // Nominal precision is 10%.
    max_attempts_for_nominal_precision_target(5),
    buffer_length(16384), 
    n_samples(0),
    scale(0),
    samples_raw(buffer_length + buffer_length),
    samples_srt(buffer_length + buffer_length),
    is_samples_double_up_to_date(false),
    samples_double(buffer_length + buffer_length),
    samples_double_re(buffer_length + buffer_length),
    medians(1000),
    measure_execution_time_counter(0),
    is_paranoid(true),
    measure_calls_counter(0),
    iterations_per_atom(0) {
    reset_chrono_overhead();
  }

  template <typename ticks, typename ticks_wall>
  void generic_timer<ticks,ticks_wall>::calibrate_chrono_overhead() {
    // Reset the overhead.
    reset_chrono_overhead();
    
    // Measure the execution time of the chronometer, assuming that we
    // are linearly regressing the number y=m*T and x = m + 1, the +1
    // is because we need to take in to account the extra call of the
    // clock.
    double __;
    measure_infinity_time(chrono, 
			  overhead_clock, 
			  __, 
			  overhead_spread, 1);

    // Repeat the timing, this time we can account for the clock
    // overhead and have a reasonable estimate of the clock error.
    measure_infinity_time(chrono,
			  overhead_clock,
			  __,
			  overhead_spread);
    // Assuming a uniform distribution, the half width is given by
    // 2*MAD. If the distribution is uniform, all observations will be
    // within +/- 2*MAD of the median.
    // 
    // With normally distributed random variables it is common to set
    // any error bound to +/- 2\sigma corresponding to the 95.4%
    // interval. The 95.4% bound for a uniform distribution is
    // 1.9*MAD.
    overhead_spread *= 1.9;    
  }

  template <typename ticks, typename ticks_wall>
  void 
  generic_timer<ticks,ticks_wall>::
  calibrate_seconds() {
    ticks_wall chrono_wall_start,chrono_wall_end;
    ticks      chrono_start,chrono_end;
    chrono_wall_start = chrono_wall();
    chrono_start = chrono();
    while (chrono_wall()-chrono_wall_start < chrono_wall_scale*4);
    chrono_end = chrono();
    chrono_wall_end = chrono_wall();
    chrono_scale = double(chrono_difference(chrono_end,chrono_start))/double(chrono_wall_end-chrono_wall_start);
    chrono_scale *= chrono_wall_scale;
    chrono_scale = 1.0/chrono_scale;
  }

  template <typename ticks, typename ticks_wall>
  template <class _Operation>
  void 
  generic_timer<ticks,ticks_wall>::
  measure_infinity_time(_Operation f, 
			double &slope, 
			double &intercept, 
			double &mad, 
			size_t m_offset) {
    
    // Clear the working spaces and reset the iteration count.
    xs.clear();  
    ys.clear();
    residuals.clear();
    tmp.clear();
    
    // Estimate the minimum number of iterations for the given nominal
    // precision.  This is the unit of iterations that we increment
    // by.
    unsigned delta_m=estimate_atom_iterations(f);


    double scale,		/**< Scale between recorded times and
				   nominal unit slope. */
      nominal_unit_slope,	/**< The scaled slope, which should
				   converge to 1.0 */
      nominal_unit_slope_max,	/**< Upper bound on recorded slope. */
      nominal_unit_slope_min;	/**< Lower bound on recorded slope. */
    double __;
    unsigned m(delta_m);
    unsigned n(0);
    do { 
      if (xs.size() >= xs.capacity())
	break;

      // Add points to the x,y plot from which we determine the slope.
      for (unsigned iter=0; iter < batch; ++iter,++n,m+=delta_m) {
	iterations_per_atom = m;
	xs.push_back(double(m + m_offset)/double(delta_m));
	ys.push_back(measure_execution_time(f)*double(m));
      }

	// Make sure the tmp and residuals are large enough.
	  tmp.resize(xs.size());
	  residuals.resize(xs.size());

      // Carry out a linear fit, from which we determine the slope.
      ejg::statistics::robust_linear_fit(xs.begin() ,  xs.begin() + n,
					 ys.begin() ,  ys.begin() + n,
					 tmp.begin(), tmp.begin() + n,
					 intercept,  slope, __);
      


      /* Determine the absolute value of the residuals between the fit
	 and the observed times. */
      for (size_t index=0; index < n; ++index) 
	residuals[index] = std::abs(ys[index] - (slope*xs[index] + intercept) );

      /* Determine the median of sorted residuals - the median
	 absolute deviation (MAD) */
      std::sort(residuals.begin(),residuals.begin()+n);
      mad = ejg::statistics::median(residuals.begin(),residuals.begin()+n);
 
      // Scale between the recorded size and the nominal unit slope
      // scale.  This scale assumes that if we double the number of
      // iterations we double the length of time taken to run it.  For
      // a sane system this should be reasonable - however it is not
      // guaranteed.
      scale              = xs.back()/ys.back();
      nominal_unit_slope = scale*slope;

      /* Based on a variation of 2xMAD, determine the maximum and
	 minimum possible slopes. */
      double Dx = xs.back() - xs.front();
      double Dy = 2.0*mad;
      double slope_min = (slope*Dx - 2.0*Dy)/Dx;
      double slope_max = (slope*Dx + 2.0*Dy)/Dx;
      /* Limits of the slope based on the chord through the upper and
	 lower limits of the residuals to the robust linear fit. */
      nominal_unit_slope_min = slope_min*scale;
      nominal_unit_slope_max = slope_max*scale;

      /* We require the nominal unit slope to be within the required
	 nominal percentage error of 1.0. */
    } while (nominal_unit_slope_max > 1.0+get_nominal_precision_target_percent()/100.0 ||
	     nominal_unit_slope_min < 1.0-get_nominal_precision_target_percent()/100.0);
  
  /* Scale the slope by the normalising factor delta_m, so we are back
     to units of 'per iteration'. */
  slope *= 1.0/delta_m;
  iterations_per_atom = 0;
  }

  template <typename ticks, typename ticks_wall>
  template <class _OperationA, class _OperationB>
  void 
  generic_timer<ticks,ticks_wall>::
  measure_percentage_speedup(_OperationA fb,
			     _OperationB fa,
			     double &MinPercent,
			     double &MedPercent,
			     double &MaxPercent) {
    /* This must always be true. */
    assert(t_a.size() == t_b.size());
        
    // 0) Clear the times, this is not strictly needed, however we do
    // it anyway!
    for (unsigned index=0; index < t_a.size(); t_a[index]=0, t_b[index]=0, ++index);

    // 1) Form a list of evaluation order and randomly shuffle it.
    std::vector<unsigned> evaluation_order(t_a.size());
    for (unsigned value(0); value < evaluation_order.size(); ++value) 
      evaluation_order[value] = value;
    std::random_shuffle(evaluation_order.begin(),evaluation_order.end());
    
    // 1) Form list of iteration counts to try.
    std::vector<unsigned> iterations_a(t_a.size());
    iterations_per_atom = 0;
    t_a[evaluation_order[0]] = measure_execution_time(fa);
    for (unsigned index(0), it = iterations_per_atom; index < t_a.size(); ++index, it += it/2+1) 
      iterations_a[index] = it;
    
    // 2) Form a list of iteration counts for function b.
    std::vector<unsigned> iterations_b(t_b.size());
    iterations_per_atom = 0;
    t_b[evaluation_order[0]] = measure_execution_time(fb);
    for (unsigned index(0), it = iterations_per_atom; index < t_b.size(); ++index, it += it/2+1) 
      iterations_b[index] = it;

    // 3) Form a list of true if we should evaluate function a first.
    std::vector<bool> time_a_first(t_a.size());
    for (unsigned index=1; index < t_a.size(); ++index) 
      time_a_first[evaluation_order[index]] = ejg::statistics::rand01() > 0.5 ? false : true;

    // 5) Now iterate over this stuff starting from the next index
    // since we have evaluated index==0 when we determined the initial
    // number of iterations.
    unsigned item;
    for (unsigned index=1; index < evaluation_order.size(); ++index) {
      item = evaluation_order[index];
      if (time_a_first[item]) {
	iterations_per_atom = iterations_a[item];
	t_a[item] = measure_execution_time(fa);
	iterations_per_atom = iterations_b[item];
	t_b[item] = measure_execution_time(fb);
      } else {
	iterations_per_atom = iterations_b[item];
	t_b[item] = measure_execution_time(fb);
	iterations_per_atom = iterations_a[item];
	t_a[item] = measure_execution_time(fa);
      }
    }

    // 6) Now apply the Wilcoxon test.
    wilcoxon_confidence_bounds(MinPercent,MedPercent,MaxPercent);
  }

  template <typename ticks, typename ticks_wall>
  template <class _Operation>
  ejg::ticks::difference_type 
  generic_timer<ticks,ticks_wall>::
  time_raw_atom( _Operation f)  {
    ticks t0,t1;
    ejg::ticks::difference_type delta(std::numeric_limits<ejg::ticks::difference_type>::max());
      
    counter attempt=0;

    /* Only permit two attempts. */
    for (;attempt < 2; ++attempt) { 

      /* Time a set of function calls. */
      t0 = chrono();
      for (counter n=0; n < iterations_per_atom; ++n, ++measure_calls_counter) f();
      t1 = chrono();

      /* If the time difference were to be negative, try again. */
      if (chrono_difference(t1,t0) < 0)
	continue;    
      
      delta = chrono_difference(t1,t0);
      break;
    }

    /* Return the time difference. */
    return delta;
  }

  template <typename ticks, typename ticks_wall>
  double
  generic_timer<ticks,ticks_wall>::
  get_nominal_precision_percent(ejg::ticks::difference_type mTm) {
    return 100.0*std::abs((1.0 + get_chrono_sigma())/(double(mTm) - (get_chrono_overhead() + get_chrono_sigma()) ) );
  } 
  
  template <typename ticks, typename ticks_wall>
  template <class _Operation>
  typename generic_timer<ticks,ticks_wall>::counter
  generic_timer<ticks,ticks_wall>::estimate_atom_iterations( _Operation f ) {
    /* Determine the maximum percentage error for increasing m,
       bailing out when it is less than the threshold. */
    ejg::ticks::difference_type total_ticks(0);
    /* Grow the number of iterations carried out until the nominal
       precision is better than the threshold. */
    counter next_iterations(1),total_iterations(0);
    for (counter trys(0); trys < max_attempts_for_nominal_precision_target; 
	 ++trys, next_iterations *= 2) {
      do {
	iterations_per_atom = next_iterations;
	total_ticks += time_raw_atom(f);
	total_iterations += next_iterations;
	next_iterations += (next_iterations/2 > 1) ? next_iterations/2 : 1;
      } while (get_nominal_precision_percent(total_ticks) > 
	       get_nominal_precision_target_percent());
      
      /* Check to see if the given number of iterations does yield the
	 nominal precision */
      iterations_per_atom = total_iterations;
      total_ticks = time_raw_atom(f);
      if (get_nominal_precision_percent(total_ticks) < 
	  get_nominal_precision_target_percent() ) 
	break;
    }

    iterations_per_atom = total_iterations;
    return iterations_per_atom;
  }

  template <typename ticks, typename ticks_wall>
  void 
  generic_timer<ticks,ticks_wall>::
  wilcoxon_confidence_bounds(double &MinPercent,
			     double &MedPercent,
			     double &MaxPercent) {
    assert(t_a.size() == t_b.size());

    for (size_t idx=0; idx < t_a.size(); ++idx) 
      z[idx] = std::log(t_a[idx]) - std::log(t_b[idx]);
    
    double a1,b1,a2,b2,med;
    ejg::statistics::wilcoxon_ci(z.begin(),z.end(),get_alpha_percentage_speedup(),a1,b1,a2,b2,med);
    MinPercent = 100.0*(std::exp(a2)-1.0);
    MaxPercent = 100.0*(std::exp(b2)-1.0);
    MedPercent = 100.0*(std::exp(med)-1.0);
  }

						       


  template <typename ticks, typename ticks_wall>
  template <class _Operation>
  timer_result_type &
  generic_timer<ticks,ticks_wall>::
  measure_execution_result(_Operation f,
			   timer_result_type &result) {
    ticks self_time_0 = chrono();
    counter loop_count=0;

    /* Start by estimating how many iterations an atom should be based
       on the desired accuracy. */
    if (iterations_per_atom == 0)
      estimate_atom_iterations(f);
    is_samples_double_up_to_date=false;
    scale = 1.0/double(iterations_per_atom);
    size_type length(8); /*< At least twice the number of samples for
			   a good KS approx. */
    counter count=0; /*< Count of the samples
		       taken. */
      
    /* Low precision timer that can be scaled to user space seconds,
       used for invoking an internal timeout. */
    ticks_wall t_start;
    iterator last_start1,last_start2;
    /* Set the maximum and minimum to be the opposite ends of the
       numeric representation. */
    ejg::ticks::difference_type max_global_ticks(std::numeric_limits<ejg::ticks::difference_type>::min()),
      min_global_ticks(std::numeric_limits<ejg::ticks::difference_type>::max());

    size_type i2(0),idx2(0),next_length(length);
    n_samples = 0;
    double delta_clock;
    is_timeout = false;
    /* Get a benchmark for the start of the execution of this
       function, ignoring the time taken to determine the minimum
       number of ticks. */
    t_start = chrono_wall();
    for (loop_count=0;;++loop_count) {
      //    take_measurements:
      /* Determine approximately how long I have been running. */
      delta_clock = static_cast<double>(chrono_wall()-t_start);
	
      /* If max_time_seconds indicates we wish to set a time limit on
	 timing and we exceed it break out. */
      if ( max_time_seconds > 0.0 &&
	   delta_clock/chrono_wall_scale >= max_time_seconds ) {
	is_timeout=true;
	goto calculate_median;
      }	
	
      /* Carry out 2*length measurements and place them alternately in
	 the two buffers, incrementing the index to the end element. We
	 use the % operator to make certain that our index in to the
	 buffer is modulo its length. */
      size_type i(0); ejg::ticks::difference_type t0(0);
      for (i=0; i < length*2; ++i, ++count) {
	t0 = time_raw_atom(f);
	samples_raw[i2=idx2++%(buffer_length + buffer_length)] = t0;
	  
	/* Keep track of the maximum and minimum values that have been observed. */
	if (t0 < min_global_ticks) min_global_ticks = t0;
	if (t0 > max_global_ticks) max_global_ticks = t0;
      }

      /* The length of the sample buffer is simply the minimum of the
	 index and buffer length. */
      n_samples = std::min(idx2/2,buffer_length);
	
      /* The calculation of the p value corresponding to the Kuiper /
	 KS statistic is an asymptotic approximation.  It is an
	 excellent approximation when the effective number of samples,
	 en > 4 (See Numerical Recipes).  If we have taken
	 insufficient samples don't bother calculating the
	 statistics. */
      double en(ejg::statistics::en(n_samples,n_samples));
      if ( (en < 4.0) & !is_timeout)
	continue;
      
#ifdef _EJG_USE_STRIDING_ITERATOR_
      /* The following can probably be done with a fast memcpy().  */
      std::copy(samples_raw.begin(), 
		samples_raw.begin() + n_samples + n_samples, 
		samples_srt.begin());

      /* Build a pair of striding iterators that will stride over the
	 interleaved samples. */
      ejg::striding_iterator<iterator> a_begin(samples_srt.begin()+0,2);
      ejg::striding_iterator<iterator> b_begin(samples_srt.begin()+1,2);
#else    
      /* The issue of a striding iterator is far from well understood.
	 For now I have to put up with a copy of the raw samples to
	 non interleaved arrays. This has the side-effect of
	 interfering with the process I'm trying to measure since the
	 following call to KS is inefficient. */

      /* Copy the raw samples to the sortable list. */
      for (unsigned int src_idx=0, idx_a=0, idx_b=n_samples;
	   src_idx < n_samples + n_samples; src_idx+=2) {
	samples_srt[idx_a++] = samples_raw[src_idx + 0];
	samples_srt[idx_b++] = samples_raw[src_idx + 1];
      }

      /* Obtain a pair of iterators, one to each aliased subsection of
	 the now contiguous vector. */
      iterator a_begin(samples_srt.begin()+0        );
      iterator b_begin(samples_srt.begin()+n_samples);
#endif

      /* Sort the buffers to prepare for the ks statistic.  */
      std::sort(a_begin, a_begin + n_samples); 
      std::sort(b_begin, b_begin + n_samples); 
      
      /* Apply the KS (Kolmogorov-Smirnov) two-sample test to try and
	 reject the hypothesis that the samples are drawn from the
	 same underlying probability density function.
	 
	 When we no-longer fail to reject this hypothesis we assume
	 that we have observed enough data to estimate a meaningful
	 (excuse the pun) median. */
      statistics::ks_test(a_begin, a_begin + n_samples,
      			  b_begin, b_begin + n_samples,
      			  result.d);

      /* Determine the probability that the pdfs are the same by
       chance alone for an observed deviation of twice the smallest
       resolvable difference in the cdf.  This places a lower bound on
       the probability threshold for small sample sizes. */
      double p_minimum = 1.0-ejg::statistics::ks_test_p(2.0/en,en);
       
     /* Determine the confidence probability.  This can be interpreted
	as the probability that the two samples of the pdfs are the
	same by chance alone. */
      double p_estimate = 1.0-ejg::statistics::ks_test_p(result.d,en);


      /* If this probability is above the minimum threshold, set by
	 the quantisation limit of the CDF and below the upper
	 threshold, set by the user assume they are the same! 

	 The lower limit effectively sets the minimum sample size. */
      if (p_estimate >= p_minimum && p_estimate < alpha_d) 
	goto calculate_median;
      
      
      /* Reduce the length of the next trial, to a limit of around 16. */
      next_length = length -  static_cast<size_t>(std::ceil(double(length) / 4.0)) + 4;

      /* Only allow the length to be the same as the buffer length. */
      length = next_length >= buffer_length ? buffer_length : next_length;
    }
     
  calculate_median:
    iterator begin(samples_srt.begin());
    iterator end(samples_srt.begin() + n_samples + n_samples);

    /* Sort all the data, it will nearly be sorted already. */
    std::sort(begin,end);

    /* Determine the final median, mad and range of the distribution. */
    result.iterations_per_atom = iterations_per_atom;
    result.raw_atom_min = *begin;
    result.raw_atom_max = *(end-1);
    result.raw_atom_median = statistics::median(begin,end); 
    std::vector<ejg::ticks::difference_type> tmp(samples_srt);
    result.raw_atom_global_max = max_global_ticks;
    result.raw_atom_global_min = min_global_ticks;
    result.count_calls = measure_calls_counter;

    /* Scaling and shift of samples. */
    result.min = rescale_atom(result.raw_atom_min);
    result.max = rescale_atom(result.raw_atom_max);
    result.median = rescale_atom(result.raw_atom_median);
    result.global_max = rescale_atom(result.raw_atom_global_max);
    result.global_min = rescale_atom(result.raw_atom_global_min);
    result.measure_execution_self_time = chrono_difference(chrono(),self_time_0);

    /* By default return the scaled median time. */
    ++measure_execution_time_counter;
    r = result;
    return result;
  }
  

  template <typename ticks, typename ticks_wall>
  template <class _Operation>
  double generic_timer<ticks,ticks_wall>::measure_execution_time(_Operation f) {
    measure_execution_result(f,r);
    return r.median;
  }
    
  template <typename ticks, typename ticks_wall>
  void 
  generic_timer<ticks,ticks_wall>::
  set_alpha_percentage_speedup(double a) {
    alpha=a;
    t_a.resize(ejg::statistics::wilcoxon::min_sample_size(alpha)+1);
    t_b.resize(t_a.size());
    z.resize(t_a.size());
  }

  template <typename ticks, typename ticks_wall>
  void generic_timer<ticks,ticks_wall>::rescale()  {
    for (counter n=0; n<n_samples+n_samples; ++n) 
      samples_double[n] = rescale_atom(samples_raw[n]);
    is_samples_double_up_to_date=true;
  }



  template <typename ticks, typename ticks_wall>
  void 
  generic_timer<ticks,ticks_wall>::
  measure_execution_time_confidence_bounds(double &min,
					   double &median,
					   double &max) {
    /* Generate convenience scaled double source. */
    rescale();
    
    double delta;
    for (unsigned long n=0; n<medians.size(); ++n) {
      /* Re-sample the data. */
      ejg::statistics::resample(samples_double.begin(), 
				samples_double.begin() + n_samples + n_samples,
				samples_double_re.begin());

      /* Perturb the final samples to generate. */
      for (counter m=0; m<n_samples+n_samples; ++m) {
	delta = 0;
	delta += ejg::statistics::epanehnikov()*2.0*scale + 
	  ejg::statistics::epanehnikov()*get_chrono_sigma()*scale;
	samples_double_re[m] += delta;
      }

      /* Sort it. */
      std::sort(samples_double_re.begin(),
		samples_double_re.begin() + n_samples + n_samples);
      
      medians[n] = ejg::statistics::median(samples_double_re.begin(),
					   samples_double_re.begin() + 
					   n_samples + n_samples);
    }


    /* We know the median, or any other time, cannot be known in
       principle to better than one clock cycle.  This places a limit
       on the minimum width of the final distribution.  We therefore
       finally convolve with an approximate random Gaussian of width
       corresponding to this single tick uncertainty. */
    for (std::vector<double>::iterator it = medians.begin(); it != medians.end(); ++it) 
      *it += ejg::statistics::crude_randn(6)*scale/2.0;
    


    std::pair<double,double> ab;
    std::sort(medians.begin(), medians.end());
    median = ejg::statistics::median(medians.begin(),medians.end());
    ab=ejg::statistics::interval_of_median(medians.begin(), medians.end());
    min = ab.first;  max = ab.second;
  }
}



//
// $Log: timer.cpp,v $
// Revision 1.6.2.3  2009/07/20 19:01:26  graceej
// * Fixed a reinitialisation error with temporary storage.
//
// Revision 1.6.2.2  2009/07/20 18:34:40  graceej
// * Modified to avoid needing a striding iterator.
// * Copy is now done the ugly way.
//
// Revision 1.6.2.1  2009/07/20 14:18:05  graceej
// * Modifications to compile under MSVC
//
// Revision 1.6  2009/07/20 10:21:53  graceej
// * Significant changes to avoid the assumption that clock tick types can be directly manipulated.
// * We now assume all clock differences can be stored as doubles.
// * This clearly needs review and thought.
//
// Revision 1.5  2009/07/20 09:07:45  graceej
// * Added undefs to prevent errors when compiling under Windows.
// * Carried out explicit static cast.
// * Addded missing include.
//
// Revision 1.4  2009/07/19 17:45:46  graceej
// * Corrected warning raised -ansi -pedantic.
//
// Revision 1.3  2009/07/18 18:21:04  graceej
// * Explicit type cast.
//
// Revision 1.2  2009/07/18 14:26:55  graceej
// * Weeded the code to smarten up its layout and remove unwanted functions.
// * Brought over these changes to the HEAD branch.
// * Prepare for upload of timer to boost vault.
//
// Revision 1.1.2.2  2009/07/18 12:37:23  graceej
// * Rationalised classes and names.
//
// Revision 1.1.2.1  2009/07/17 18:21:12  graceej
// * Reorganised code so that the directory structure matches the namespace structure.
//
// Revision 1.34.2.2  2009/07/17 16:45:05  graceej
// * Documentation nearly complete.
//
// Revision 1.34.2.1  2009/07/17 14:01:50  graceej
// * Moved essential functions and documented them.
//
// Revision 1.34  2009/07/16 17:12:00  graceej
// * Added scaling function to real units.
//
// Revision 1.33  2009/07/16 16:40:48  graceej
// * Linear fit now works reliably and sanely.
// * Point estimates now work correctly with KS test.
//
// Revision 1.32  2009/07/09 16:42:14  graceej
// * Moved the linear regression code in to a separate function.
//
// Revision 1.31  2009/07/09 13:15:31  graceej
// * Modified so that the sigma of the clock is more meaningful.
//
// Revision 1.30  2009/07/08 18:30:28  graceej
// * Reviewing code and correcting.  The intercept is likely to be a meaninless parameter and should be ignored.
//
// Revision 1.29  2009/07/02 09:17:43  graceej
// * Modified form of timer.hpp to fail to reject based on the p-value rather than the raw statistic.
//
// Revision 1.28  2009/06/30 15:20:26  graceej
// * Measure the range of median execution times over a set of iterations.
//
// Revision 1.27  2009/06/26 19:30:59  graceej
// * Arbitrary check in for testing of compilation under linux.
//
// Revision 1.26  2009/03/24 01:03:42  graceej
// * Checked and working!
//
// Revision 1.25  2009/03/23 11:44:24  graceej
// * Example of increasing precision to detect a difference in execution times.
//
// Revision 1.24  2009/03/17 21:32:49  graceej
// * Minor bug fix.
//
// Revision 1.23  2009/02/22 14:00:02  graceej
// * Seperate out the determination of the appropriate number of iterations.
//
// Revision 1.22  2009/02/12 15:46:06  graceej
// * Record the d statistic that was observed for the time to investigate the clock.
//
// Revision 1.21  2009/02/10 22:12:00  graceej
// * Updated to use revised results.
//
// Revision 1.20  2009/02/05 20:37:55  graceej
// * Working.
//
// Revision 1.19  2009/02/05 14:10:18  graceej
// * Simpified interface
//
// Revision 1.18  2009/02/05 11:40:13  graceej
// * Simpified interface
//
// Revision 1.17  2009/01/17 15:41:49  graceej
// * Conceptually simplified now we use strided iterators and interleaved data.
//
// Revision 1.16  2009/01/16 12:31:30  graceej
// * Require that the Kuiper statistic be non zero.
// * The Kuiper statistic can be exactly zero with few samples not because it should be, but because of chance.
//
// Revision 1.15  2009/01/16 10:48:29  graceej
// * change of function name.
//
// Revision 1.14  2009/01/16 09:31:10  graceej
// * Return percentile widths of observations.
//
// Revision 1.13  2009/01/15 10:33:54  graceej
// * Simplified structure.
// * Added documentation.
// * Added functor adaptors.
//
// Revision 1.12  2009/01/12 16:46:25  graceej
// * First release, tagged as timer-release-1_0_0
//
//
