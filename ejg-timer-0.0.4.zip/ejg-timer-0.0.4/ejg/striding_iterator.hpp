#ifndef _EJG_STRIDING_ITERATOR_HPP_
#define _EJG_STRIDING_ITERATOR_HPP_

/**
 * @file   striding_iterator.hpp
 * @author Edward Grace <edward.grace@imperial.ac.uk>
 * @date   Sat Jan 17 13:49:30 2009
 * 
 * @brief  Implementation of an iterator class that strides.
 *
 */

#include <iterator>
#include <iostream>

namespace ejg {   
  /** 
   * @brief A striding iterator.
   * 
   * It is occasionally useful to be able to stride through a
   * container more than one element at a time.
   *  
   * When data is interleaved it is convenient to be able to get to
   * the next element by a simple increment where the increment is a
   * constant stride value.  This allows that idea to be consistent
   * with standard algorithms.
   *
   * Apart from the constructor, there is no documentation as
   * conceptually this is a random_access_iterator and should behave
   * like one!
   *
   * This class was inspired by mtl/strided_iterator.h and is a
   * model of a random access iterator.
   */
  template <class I>
  class striding_iterator : public std::iterator<std::random_access_iterator_tag,
						 typename std::iterator_traits<I>::value_type,
						 typename std::iterator_traits<I>::difference_type,
						 typename std::iterator_traits<I>::pointer,
						 typename std::iterator_traits<I>::reference >
  {
    typedef typename std::iterator_traits<I> trait;		       
  public:
    /** 
     * @note It seems retarded that we have to write a load of
     * typedefs. Why can't the iterator typedefs be done
     * automatically due to the inheritance of the specialised
     * iterator base class? */
    typedef typename trait::difference_type difference_type;
    typedef typename trait::value_type value_type;
    typedef typename trait::iterator_category iterator_category;
    typedef typename trait::pointer pointer;
    typedef typename trait::reference reference;
    typedef difference_type distance;   
    typedef striding_iterator<I> my_type;
  protected:
    typedef typename std::iterator_traits<I> super;
    I i;
    difference_type s;
    size_t p;
  public:
    striding_iterator() : i(0), s(0), p(0) {}
    /** 
     * @brief Construct a striding iterator starting at position i_
     * with a given stride.
     * 
     * @param initial The start position.
     * @param stride The stride (default is 1).
     * @param position The internal position counter (default 0).
     */ 
    explicit 
	striding_iterator(I initial, difference_type stride=1, size_t position=0) :
      i(initial), s(stride), p(position) {} 
    striding_iterator(const my_type& x) : i(x.i), s(x.s), p(x.p) {}
    my_type& operator=(const my_type& x) { 
	  if (this == &x) return *this;
      i = x.i; s = x.s; p = x.p; 
      return *this; 
    }
    size_t index() const { return p; }
    operator I() const { return i; }
    I base() const { return i; }
    reference operator*() const { return *i; }
    my_type& operator++() { 
		++p; 
		i += s; 
		std::cout<< __FUNCTION__ << ":" << __LINE__ << ":" << p << std::endl;
		return *this; 
	}
    my_type  operator++(int) { my_type tmp=*this; ++p; i += s; return tmp; }
    my_type& operator--() { --p; i -= s; return *this; }
    my_type  operator--(int) { my_type tmp=*this; --p; i -= s; return tmp; }
    my_type &operator+=(distance n) { i += n*s; p += n; return *this; }
    my_type &operator-=(distance n) { i -= n*s; p -= n; return *this; }
    distance operator-(const my_type& x) const { return p - x.p; }
    distance operator+(const my_type& x) const { return p + x.p; }
    my_type operator-(distance d) const { return my_type(i - d*s,s,p-d); }
    my_type operator+(distance d) const { return my_type(i + d*s,s,p+d); }
    reference operator[](distance n) const { return *(*this + n); }
    bool operator==(const my_type& x) const { 
		std::cout << p << " ?= " << x.p << std::endl;
		return p == x.p; 
	}
    bool operator!=(const my_type& x) const { 
		std::cout << p << " ?= " << x.p << std::endl;
		return p != x.p; 
	}
    bool operator<(const my_type& x) const { return p < x.p; }
    bool operator>(const my_type& x) const { return p > x.p; }
  };
} 

namespace blitz {
	template <class RandomAccessIterator>
class strided_iterator 
{
  typedef strided_iterator self;
  
public:
  
  typedef typename std::iterator_traits<RandomAccessIterator>::difference_type   difference_type; 
  typedef typename std::iterator_traits<RandomAccessIterator>::value_type        value_type;
  typedef typename std::iterator_traits<RandomAccessIterator>::iterator_category iterator_category;
  typedef typename std::iterator_traits<RandomAccessIterator>::reference         reference;
  typedef typename std::iterator_traits<RandomAccessIterator>::pointer           pointer;

  typedef difference_type      Distance;
  typedef RandomAccessIterator iterator_type;

  inline strided_iterator() : stride(0), pos(0) { }

  inline strided_iterator(const RandomAccessIterator& x, int s, int p) 
    : iter(x), stride(s), pos(p) { }

  inline strided_iterator(const self& x)
    : iter(x.iter), stride(x.stride), pos(x.pos) { }

  inline self& operator=(const self& x) 
  {
    iter = x.iter; stride = x.stride; pos = x.pos; return *this;
  }

  inline int index() const { return pos; }
  
  inline operator RandomAccessIterator () const { return iter; }

  inline RandomAccessIterator base() const { return iter; }

  inline reference operator*() const { return *iter; }

  inline self& operator++ ()
  {
    ++pos; iter += stride; return *this;
  }

  inline self operator++ (int)
  { 
    self tmp = *this; ++pos; iter += stride; return tmp; 
  }

  inline self& operator-- ()
  { 
    --pos; iter -= stride; return *this; 
  }
  
  inline self operator-- (int)
  { 
    self tmp = *this; --pos; iter -= stride; return tmp; 
  }
 
  inline self operator+ (Distance n) const 
  {
    return self (iter + n*stride, stride, pos + n);
  }
  
  inline self& operator+= (Distance n) 
  { 
    iter += n*stride; pos += n; return *this; 
  }
  
  inline self operator- (Distance n) const 
  {
    return self (iter - n*stride, stride, pos - n);
  }
  
  inline self& operator-= (Distance n) 
  {
    iter -= n*stride; pos -= n; return *this; 
  }

  inline self operator+ (const self& x) const 
  {
    return self(iter + x.iter, stride, pos + x.pos); 
  }
  
  inline Distance operator- (const self& x) const { return pos - x.pos; }
  
  inline reference operator[] (Distance n) const { return *(*this+n); }
 
  inline bool operator==(const self& x) const { return pos == x.pos; }
  
  inline bool operator!=(const self& x) const { return pos != x.pos; }
  
  inline bool operator<(const self& x) const { return pos < x.pos; }  

protected:
  
  RandomAccessIterator iter;
  
  int stride;
  int pos;
};
}

/** \example example_striding_iterator.cpp
 *  @todo Collect together examples of usage in one place.
 *  @brief This is an example of how to use the striding_iterator class.
 * 
 *  Given a list this shows how to sort the interleaved sublists using
 *  the standard sort algorithm by simply using a striding iterator.
 */


#endif /* _EJG_STRIDING_ITERATOR_HPP_ */

//
// $Log: striding_iterator.hpp,v $
// Revision 1.2.2.3  2009/07/20 18:37:20  graceej
// * Remove example_striding_iterator.
//
// Revision 1.2.2.2  2009/07/20 14:40:58  graceej
// * Add explicit keyword to constructor of striding_iterator.
//
// Revision 1.2.2.1  2009/07/20 14:18:05  graceej
// * Modifications to compile under MSVC
//
// Revision 1.2  2009/07/18 14:26:55  graceej
// * Weeded the code to smarten up its layout and remove unwanted functions.
// * Brought over these changes to the HEAD branch.
// * Prepare for upload of timer to boost vault.
//
// Revision 1.1.2.1  2009/07/18 12:37:23  graceej
// * Rationalised classes and names.
//
// Revision 1.1.2.3  2009/07/18 12:31:19  graceej
// * Added link to example and renamed class.
//
//
