
//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//

// 
// CVS Information
//
// $Author: graceej $ $Date: 2009/07/20 14:18:06 $
// $Revision: 1.4.2.1 $
//


/**
 * @file   statistics.hpp
 * @author Edward Grace <edward.grace@imperial.ac.uk>
 * @date   Wed Jan  7 17:16:40 2009
 * 
 * @brief A set of templated algorithms for conducting
 * statistical tests on sorted ranges of data.
 * 
 */

#ifndef _EJG_STATISTICS_HPP_
#define _EJG_STATISTICS_HPP_
#include <iterator> /* For iterator_traits */
#include <cmath>
#include <cstdlib>

namespace ejg {
  /** 
   * @brief Determine the absolute difference between two possibly
   * unsigned values.
   * 
   * @return a-b or b-a such that the sign of the result is positive.
   */
  template <typename ComparableNumericType>
  ComparableNumericType inline absdiff(ComparableNumericType a, ComparableNumericType b) {
    return a > b ? a - b : b - a;
  } 

}

namespace ejg { namespace statistics {

    /** 
     * @brief Determine the median of a sorted range of values.
     *
     * 
     * @param begin An iterator to the start of the range.
     * @param end An iterator to the end of the range.
     *
     * @return The median value.
     */
    template <class _Input_Iterator>
    typename std::iterator_traits<_Input_Iterator>::value_type  
    median(_Input_Iterator  begin,
	   _Input_Iterator  end);
    
    /** 
     * @brief Return the mean value of a range.
     * 
     * @param begin An iterator to the start of the range.
     * @param end An iterator to the end of the range.
     * 
     * @return The mean value.
     */
    template <class _Input_Iterator>
    double 
    mean(_Input_Iterator begin, _Input_Iterator end);


    /** 
     * @brief Determine the variance of a set of data in a range.
     *
     *        This calculates the variance in a two pass manner to
     *        reduce rounding error.
     * 
     * @param begin An iterator to the beginning of the range.
     * @param end An iterator to the end of the range.
     * 
     * @return The variance from the mean of the data.
     */template <class _Input_Iterator>
    double 
    var(_Input_Iterator begin, _Input_Iterator end);


    /** 
     * @brief Return the standard deviation \f$\sigma\f$ of a range.
     * 
     * @param begin An iterator to the beginning of the range.
     * @param end An iterator to the end of the range.
     * 
     * @return The standard deviation, the square root of the
     * variance.
     */    template <class _I>
    double
    stddev(_I begin, _I end);

    /** 
     * @brief Determine the median absolute deviation (MAD) of a sorted
     * range of values.
     *
     * This algorithm modifies a sorted range yielding the sorted absolute
     * deviation of each point from the median of the range returning the
     * median of the absolute deviation of this range.
     *
     * @param begin An iterator to the start of the range
     * @param end An iterator to the end of the range
     * @param begin_temp An output iterator to temporary storage that
     * must be sufficient to store end-begin elements.
     * 
     * @return The median absolute deviation (MAD).
     */
    template <class _Input_Iterator, class _Output_Iterator>
    typename std::iterator_traits<_Input_Iterator>::value_type 
    mad(_Input_Iterator begin,
	_Input_Iterator end,
	_Output_Iterator begin_tmp);


    /** 
     * @brief Return the value of a sorted range at the given
     * percentile.
     *
     * This assumes that the data in the range is sorted. This should
     * agree with the median value for a percentile of 50.0, however
     * due to minor differences in their calculation they may differ
     * slightly.
     * 
     * @param percentile The percentile to return
     * @param begin An iterator to the start of the range.
     * @param end An iterator to the end of the range.
     * 
     * @return The value at the given percentile.
     */    
    template <class _Input_Iterator>
    typename std::iterator_traits<_Input_Iterator>::value_type
    percentile_of_sorted_range(double percentile, 
			       _Input_Iterator begin,
				_Input_Iterator end);
	
    /** 
     * @brief Return a confidence interval for a set of data.
     *
     *        Given a set of observed data that has been sorted this
     *        will return the range bounded by two percentiles about
     *        the median such that the range includes the requested
     *        percentage of the observations.  By default the 95.4%
     *        level is used corresponding to \f$2\sigma\f$ for a
     *        normal distribution.
     * 
     * @param begin An iterator to the start of the observation data.
     * @param end An iterator to the end of the observation data.
     * @param percentage The confidence level required.
     * 
     * @return A pair of values marking the range over which the
     * requested percentage of observations are observed.
     */
    template <class _Input_Iterator>
    std::pair<typename std::iterator_traits<_Input_Iterator>::value_type,
	      typename std::iterator_traits<_Input_Iterator>::value_type>
    interval_of_median(_Input_Iterator begin,
		       _Input_Iterator end,
		       double percentage = 95.4);
    

    /** 
     * @brief Returns a random number between 0.0 and 1.0 from the
     * uniform deviate.
     * 
     * @bug std::rand() is generally considered to be evil.
     * @todo This should be made to use a sensible random number generator (see Boost).
     * @return A random double precision value between 0.0 and 1.0.
     */
    double rand01() {
      static const double scale (1.0/static_cast<double>(RAND_MAX));
      return static_cast<double>(std::rand())*scale;
    }

    /** 
     * @brief A crude approximation to a normally distributed random
     * variable with zero mean and unit variance.
     *
     * @param M the number of uniform variates to convolve, by default this is 5.
     *
     * @return The convolution of 5 uniform random numbers
     */
    double crude_randn(unsigned M = 5) {
      static double sum(0.0);
      static const double d_M(static_cast<double>(M));
      // Scale to generate appropriate variance.
      static double scale(1.0/std::sqrt(d_M/12.0));
      sum = 0.0;
      for (unsigned n=0; n<M; ++n) 
	sum += rand01()-0.5;
      sum *= scale;
      return sum;
    }

    /** 
     * @brief Return a random variate corresponding to the rescaled
     * Epanechnikov kernel.  This is useful as an error minimising
     * smoothing kernel for kernel density estimation.
     *
     * @return A random variate corresponding to the Epanechnikov
     * distribution.
     */
    double epanehnikov() {
      double v1,v2,v3,v3abs,eps;
      v1 = rand01()*2.0-1.0;
      v2 = rand01()*2.0-1.0;
      v3 = rand01()*2.0-1.0;
      eps = v3;
      v3abs = std::abs(v3);
      if (v3abs >= std::abs(v2) && v3abs >= std::abs(v1))
	eps=v2;
      return eps;
    }
    
    /** 
     * @brief Re-sample data from the input range randomly with
     *        replacement and place it in to the output range.
     *
     *        This algorithm assumes that the output is capable of
     *        accepting i_end-i_begin elements.
     *
     * @deprecated This should be deprecated in favour of a random
     * input iterator adaptor for which operator++ is overloaded to
     * return another random element.
     *
     * @param i_begin An input iterator to the start of the input range.
     * @param i_end An input iterator to the end of the input range.
     * @param o_begin An output iterator to the start of the output
     * range.
     */
    template <class _Input_Iterator, 
	      class _Output_Iterator>
    void
    resample(_Input_Iterator i_begin,
	     _Input_Iterator i_end,
	     _Output_Iterator o_begin);
    

    /** 
     * @brief Return the Kolmogorov-Smirnov probability function.
     *
     * See: von Mises, R. 1964 "Mathematical Theory of Probability and
     * Statistics".
     * 
     * @param lambda The argument.
     * @param required_precision The precision to find (default 1E-3).
     * @param max_j The maximum number of terms to calculate.
     * 
     * @return The result.
     */
    template <class FloatType>
    FloatType qks(FloatType x, 
		  FloatType required_precision = 1E-7, 
		  unsigned max_j = 100);

    /** 
     * @brief Determine the confidence parameter associated with the
     * Kuiper statsitic.
     * 
     * @param x The Kuiper statistic
     * @param required_precision The required numerical precsion.
     * @param max_j The maximum number of iterations.
     * 
     * @return The confidence p value.
     */
    template <class FloatType>
    FloatType qkp(FloatType x, 
		  FloatType required_precision = 1E-7, 
		  unsigned max_j = 1000);

    /** 
     * @brief Determine the effective number of samples given n1 and n2.
     * 
     * @param n1 A constant reference to the number of samples in the first set.
     * @param n2 A constant reference to the number of samples in the second set.
     * @param en A reference to the effective number of samples.
     * 
     * @return A reference to the effective number of samples.
     */
    template <typename _Float_Type, typename _Size_Type>  
    _Float_Type &en(_Float_Type &en, _Size_Type n1, _Size_Type n2); 

    template <typename _Size_Type>
    double en(_Size_Type n1, _Size_Type n2) {
      double neff; 
      en(neff,n1,n2);
      return neff;
    }

    /** 
     * @brief Conduct a Kolmogorov-Smirnov test on two sets of
     * discrete data.
     *
     * Given two ranges of sorted data samples conduct the K-S test to
     * determine if they are drawn from the same (potentially
     * empirical) probability distribution.
     *
     * The effective number of samples, \f$e_n >> 4\f$ for measures of
     * the p parameter to be meaningful.  As an example if you obtain,
     * for two different sets of samples, a value d=0.005 and p=0.95
     * and en=100 you could say - if you were feeling brave and ignore
     * the subtleties of the null hypothesis "Yes a and b are drawn
     * from the same distribution."
     * 
     * @param a_begin A const iterator to the beginning of the first samples
     * @param a_end A const iterator marking the end of the first samples
     * @param b_begin A const iterator to the beginning of the second samples
     * @param b_end A const iterator to the end of the second samples.
     * @param d A reference to the returned statistic d.
     * @param en A reference to the effective number of samples in the
     * two populations.
     * @param absolute A flag to indicate that the distance between
     * the two CDFs should be unsigned.
     */
    template <class _Input_Iterator, class FloatType >
    void ks_test( const _Input_Iterator a_begin,
		  const _Input_Iterator a_end,
		  const _Input_Iterator b_begin,
		  const _Input_Iterator b_end,
		  FloatType &d,
		  bool absolute = true);

    template <class FloatType>
    FloatType ks_test_p(FloatType d, FloatType en);

    template <class FloatType, class IntType>
    FloatType ks_test_p(FloatType d, IntType en) {
      return ks_test_p(d,FloatType(en));
    }
    

    /** 
     * @brief Confidence value for the Kolmogorov-Smirnov test for
     * large numbers of effective samples.
     *
     * If en is less than 4 this returns zero since the value is an
     * asymptotic approximation only valid for large \f$e_n\f$
     * 
     * @param d The KS statistic
     * @param en The effective number of samples.
     * 
     * @return The value of p. 
     */
    template <class FloatType>
    FloatType ks_p(FloatType d, FloatType en);
    
    /** 
     * @brief An implementation of the Kuiper test.
     *
     * This modification to the Kolmogorov-Smirnov test treats all
     * points of the cumulative distribution function with equal
     * importance it is effectively just the sum of the maximum and
     * minimum signed difference between the two cumulative
     * distribution functions.
     *
     * @param a_begin A const iterator to the beginning of the first samples
     * @param a_end A const iterator marking the end of the first samples
     * @param b_begin A const iterator to the beginning of the second samples
     * @param b_end A const iterator to the end of the second samples.
     * @param v A reference to the desired Kuiper statistic.
     * @param en A reference to the effective number of samples.
     */
    template <class _Input_Iterator, class FloatType>
    void kp_test( const _Input_Iterator a_begin,
		  const _Input_Iterator a_end,
		  const _Input_Iterator b_begin,
		  const _Input_Iterator b_end,
		  FloatType &v);
    /** 
     * Return the confidence parameter relating to the Kuiper
     * statistic.
     * 
     * @param v The Kuiper statistic.
     * @param en The effective number of samples.
     * 
     * @return The confidence probability.
     */
    template <class FloatType>
    FloatType kp_test_p( FloatType v, FloatType en);

    /** 
     * @brief Functions related to Wilcoxon type rank statistics.
     * 
     */
    namespace wilcoxon {

      /** 
       * @brief The Wilcoxon-paired signed rank discrete cumulative
       * distribution function.
       * 
       * @param cdf A reference to a vector that will contain the cdf.
       * @param n The size of the two samples.
       */      
      template <class NumericVector>
      void cdf(NumericVector &cdf, unsigned n);

      /** 
       * @brief The minimum sample size required to, in principle,
       * detect at the 1-alpha level.
       * 
       * @param alpha The required rejection probability.
       * 
       * @return The minimum number of samples required to test the
       * 1-alpha projection probability.
       * @todo Check that the function is formally correct.
       * @bug Can I guarantee that this is always going to be doable with an unsigned?
       */
      unsigned min_sample_size(double a) {
	return static_cast<unsigned>(std::ceil(std::log(1.0/a)/std::log(2.0)));
      }
    }

    /** 
     * @brief Calculate the Mann-Whitney-Wilcoxon U statistic for two
     * samples. It is assumed that the ranges of values a and b have
     * been sorted in to ascending order and are comparable with
     * operator<().
     * 
     * @todo Write test for this function and test it.
     * 
     * @param begin_a An iterator to the beginning of the sorted sample a.
     * @param end_a An iterator to the end of the sorted sample a.
     * @param begin_b An iterator to the beginning of the sorted sample b.
     * @param end_b An iterator to the end of the sorted sample b.
     * @param U The U statistic.
     */    
    template <class I>
    void mann_whitney_wilcoxon(I begin_a, I end_a,
			       I begin_b, I end_b,
			       double &U);

    /** 
     * @brief Return p-value for MWW assuming large sample size.
     * 
     * @param na Number of samples in a
     * @param nb Number of samples in b
     * @param U U statistic.
     * 
     * @return p-value.
     */
    template <class size_t>
    double mann_whitney_wilcoxon_p(size_t na, size_t nb, double U) {
      double mu = 0.5*double(na)*double(nb);
      double sigma_u = std::sqrt(double(na)*double(nb)*(na + nb + 1.0)/12.0);
      double z = (U - mu)/sigma_u;
      return 0.5*(erf(z/sqrt(2.0))+1.0);
    }

    /** 
     * @brief Wilcoxon signed rank confidence limits on differences.
     * 
     * @param z Differences
     * @param alpha Desired, nominal significance level.
     * @param a1 Lower bound.
     * @param b1 Upper bound.
     * @param a2 Lower confidence interval.
     * @param b2 Upper confidence interval.
     * @param med Median estimate.
     */
    template <class I>
    void wilcoxon_ci(I begin, I end,
		     double alpha,
		     double &a1, double &b1, double &a2, double &b2, double &med);

    
    template <class V>
    inline V sign(const V &a, const V &b) {
      return b >= V(0) ? ( a >= V(0) ? a : -a) : (a >= V(0) ? -a : a);
    }

    /** 
     * @brief Robust fit of linear model.
     *
     * Robust fitting of classic straight line model to data, in a
     * manner to minimise the total absolute error.
     *
     * The iterators to x and y must not overlap. It is assumed that
     * the size of the three ranges, x,y,tmp is the same and that the
     * range of tmp does not overlap with either x or y.
     * 
     * @param x_begin Iterator to beginning of x values.
     * @param x_end Iterator to end of x values.
     * @param y_begin Iterator to beginning of y values.
     * @param y_end Iterator to end of y values.
     * @param tmp_begin Iterator to start of temporary storage.
     * @param tmp_end Iterator to end of temporary storage.
     * @param c Returned intercept.
     * @param m Returned slope.
     * @param abdev Average of absolute deviations of fit.
     * @param is_c_fixed If true robustly fits assuming the value of c for the intercept.
     */
    template <class I>
    void robust_linear_fit(I x_begin, I x_end,
			   I y_begin, I y_end,
			   I tmp_begin, I tmp_end,
			   typename std::iterator_traits<I>::value_type &c,
			   typename std::iterator_traits<I>::value_type &m,
			   typename std::iterator_traits<I>::value_type &abdev,
			   bool is_c_fixed = false);

    
  } }

/* Yes this sucks, but seems to be the best way of fudging template code!*/
#include <ejg/statistics/statistics.cpp>

#endif /* _EJG_STATISTICS_HPP__ */

//
// $Log: statistics.hpp,v $
// Revision 1.4.2.1  2009/07/20 14:18:06  graceej
// * Modifications to compile under MSVC
//
// Revision 1.4  2009/07/20 09:07:45  graceej
// * Added undefs to prevent errors when compiling under Windows.
// * Carried out explicit static cast.
// * Addded missing include.
//
// Revision 1.3  2009/07/18 18:20:11  graceej
// * Corrected call to std::rand()
// * Needed to include cstdlib
//
// Revision 1.2  2009/07/18 14:26:56  graceej
// * Weeded the code to smarten up its layout and remove unwanted functions.
// * Brought over these changes to the HEAD branch.
// * Prepare for upload of timer to boost vault.
//
// Revision 1.1.2.1  2009/07/17 18:21:12  graceej
// * Reorganised code so that the directory structure matches the namespace structure.
//
// Revision 1.14  2009/07/16 16:40:47  graceej
// * Linear fit now works reliably and sanely.
// * Point estimates now work correctly with KS test.
//
// Revision 1.13  2009/07/08 18:30:28  graceej
// * Reviewing code and correcting.  The intercept is likely to be a meaninless parameter and should be ignored.
//
// Revision 1.12  2009/06/30 15:21:01  graceej
// * Add a first draft of the Mann-Whitney-Wilcoxon rank test.
//
// Revision 1.11  2009/03/24 01:04:40  graceej
// * Added todo - check that the wilcoxon functions are correct.
//
// Revision 1.10  2009/03/19 20:12:50  graceej
// * Added robust linear fitting.
//
// Revision 1.9  2009/03/17 21:32:23  graceej
// * Added wilcoxon signed rank test to return confidence intervals for paired differences.
//
// Revision 1.8  2009/02/10 22:12:00  graceej
// * Updated to use revised results.
//
// Revision 1.7  2009/02/05 20:37:55  graceej
// * Working.
//
// Revision 1.6  2009/02/05 14:10:18  graceej
// * Simpified interface
//
// Revision 1.5  2009/01/17 10:30:43  graceej
// * Added bootstrap resampling function.
//
// Revision 1.4  2009/01/16 10:48:50  graceej
// * Rename functions and add more documentation.
//
// Revision 1.3  2009/01/12 16:46:25  graceej
// * First release, tagged as timer-release-1_0_0
//
//
