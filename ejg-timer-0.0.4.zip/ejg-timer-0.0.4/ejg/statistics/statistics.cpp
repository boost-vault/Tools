
//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//


//
// CVS Information
//
// $Author: graceej $ $Date: 2009/07/20 14:18:06 $
// $Revision
//
#include <cmath>    /* For exp, sqrt. */
#include <limits>   /* For numeric_limits */
#include <iterator> /* For iterator_traits */
#include <numeric>  /* For accumulate */
#include <algorithm>
#include <vector>
#include <functional> /* For ptr_fun */

namespace ejg { namespace statistics {
    using std::sqrt;
    using std::exp;
    using std::abs;
    using std::iterator_traits;
    using std::numeric_limits;
    using std::ptr_fun;


    template <class I_I, class O_I>
    typename iterator_traits<I_I>::value_type
    mad_aux(I_I begin,
	    I_I end,
	    O_I begin_tmp,
	    std::input_iterator_tag, 
	    std::random_access_iterator_tag) {
      typedef typename iterator_traits<I_I>::value_type value_type;
      const  value_type median_j = median(begin,end);
      /* Transform the values so we get the absolute deviation of the
	 value from the median. */
      std::transform(begin,end,begin_tmp,bind1st(std::ptr_fun(ejg::absdiff<value_type>),median_j));
      /* Sort this vector. */
      std::sort(begin_tmp,begin_tmp+(end-begin)); 
      /* Return the median. */
      return median(begin_tmp,begin_tmp+(end-begin));
    }

    template <class _Input_Iterator, class _Output_Iterator>
    typename iterator_traits<_Input_Iterator>::value_type 
    mad(_Input_Iterator begin,
	_Input_Iterator end,
	_Output_Iterator begin_tmp) {
      return mad_aux
	(begin,end,begin_tmp,
	 typename std::iterator_traits<_Input_Iterator>::iterator_category(),
	 typename std::iterator_traits<_Output_Iterator>::iterator_category()
	 );

    }


    template <class _Input_Iterator>
    typename std::iterator_traits<_Input_Iterator>::value_type
    percentile_of_sorted_range(double percentile, 
			       _Input_Iterator begin,
			       _Input_Iterator end) {
      typename iterator_traits<_Input_Iterator>::difference_type n(end-begin);
      return *(begin + std::floor(percentile*n/100.0));
    }


    template <class _Input_Iterator>
    std::pair<typename std::iterator_traits<_Input_Iterator>::value_type,
	      typename std::iterator_traits<_Input_Iterator>::value_type>
    interval_of_median(_Input_Iterator begin,
		       _Input_Iterator end,
		       double percentage) {
      std::pair<typename std::iterator_traits<_Input_Iterator>::value_type,
	typename std::iterator_traits<_Input_Iterator>::value_type> c;
      double frac=(1.0-percentage/100.0)/2.0;
      c.first = percentile_of_sorted_range(100.0*frac,begin,end);
      c.second =  percentile_of_sorted_range(100.0*(1.0-frac),begin,end);
      return c;
    }



    template <class _Input_Iterator, 
	      class _Output_Iterator>
    void
    resample(_Input_Iterator i_begin,
	     _Input_Iterator i_end,
	     _Output_Iterator o_begin) {
      typename std::iterator_traits<_Input_Iterator>::difference_type N(i_end-i_begin),
	idx=0;
      _Input_Iterator i(i_begin);
      _Output_Iterator o(o_begin);
      for ( ; i != i_end; idx = N*ejg::statistics::rand01(),++i,++o) 
	*o = *(i_begin+idx);
      
    }

    
		      


    template <class _Input_Iterator>
    typename std::iterator_traits<_Input_Iterator>::value_type
    median_aux(_Input_Iterator begin,
			       _Input_Iterator end,
			       std::input_iterator_tag) {
      typename std::iterator_traits<_Input_Iterator>::difference_type delta(end-begin);
      typedef typename std::iterator_traits<_Input_Iterator>::value_type value_type;
      /* If the length is even return the arithmetic sum, otherwise the
	 central value. */
      if (delta % 2) 
	return *(begin + (delta-1)/2);
      else {
	/* Check to see if the values straddling the center are the
	   same. */
	const value_type a(*(begin + delta/2 - 1));
	const value_type b(*(begin + delta/2));
	if ( a == b) // Do no arithmetic, just return the value.
	  return a;
	else { /* We need to try and linearly interpolate the central
		  value. */
	  const value_type a_plus_b(a + b); // This might overflow.
	  const value_type two(2);
	  /* Check if a_plus_b overflowed. 
	     See: Secord Chapter 5 "Integer Security" p192 */
	  if ( b >= 0 ? a_plus_b < a : a_plus_b > b) {
	    /* a+b overflows so resort to an arithmetic average that
	       is safe, but has greater rounding error than the
	       (a+b)/2 version.*/
	    return a/two + b/two; 
	  } else 
	    /* a+b does not overflow, so minimise rounding error. */
	    return a_plus_b/two; 
	}
	/* @bug If the type is an integer the above rounds down. */
      }
    }

    
    

    template <class _Input_Iterator>
    typename std::iterator_traits<_Input_Iterator>::value_type  
    median(_Input_Iterator  begin,
			   _Input_Iterator  end) {
      return median_aux
	( 
	 begin,end,
	 typename std::iterator_traits<_Input_Iterator>::iterator_category()
	  );
    }


    template <class _Input_Iterator>
    double 
    mean(_Input_Iterator begin, _Input_Iterator end) {
      typedef typename std::iterator_traits<_Input_Iterator>::value_type value_type;
      return static_cast<double>(std::accumulate(begin,end,0,std::plus<value_type>()))/
	static_cast<double>(end-begin);
    }


    template <class _Input_Iterator>
    double 
    var(_Input_Iterator begin, _Input_Iterator end) {
      typedef typename std::iterator_traits<_Input_Iterator>::difference_type difference_type;
      difference_type n(end-begin);
      double av(mean(begin,end));
      double avdev(0),s(0),ep(0),p(0),v(0);
      for (_Input_Iterator i(begin); i != end; ++i) {
	s = *i-av;
	avdev += std::abs(s);
	ep += s;
	p = s*s;
	v += p;
      }
      avdev /= n;
      v=(v-ep*ep/n)/(n-1);
      return v;
    }

    template <class _I>
    double
    stddev(_I begin, _I end) {
      return std::sqrt(var(begin,end));
    }



    template <class FloatType>
    FloatType qks(FloatType x, 
		  FloatType required_precision, 
		  unsigned max_j) {
      FloatType a2, fac(2.0), sum(0.0), term, termbf(0.0);
      if (x <= 0.2 )
	return 1.0;

      a2 = -2.0*x*x;
      for (unsigned j=1; j<=max_j; ++j) {
	term=fac*exp(a2*j*j);
	sum += term;
	if (abs(term) <= required_precision*termbf || 
	    abs(term) <= numeric_limits<FloatType>::epsilon()*sum ) 
	  break;
	fac = -fac;
	termbf=abs(term);
      }
      return sum;
    }



    template <class FloatType>
    FloatType qkp(FloatType x, 
		  FloatType required_precision, 
		  unsigned max_j ) {
      FloatType a2, fac(0.0), sum(0.0), term, termbf(0.0);
      if (x <= 0.51 )
	return 1.0;

      a2 = -2.0*x*x;
      for (unsigned j=1; j<=max_j; ++j) {
	fac = 2.0*(4.0*j*j*x*x - 1.0);
	term=fac*exp(a2*j*j);
	sum += term;
	if (abs(term) <= required_precision*termbf || 
	    abs(term) <= numeric_limits<FloatType>::epsilon()*sum ) 
	  return sum;
	fac = -fac;
	termbf=abs(term);
      }
      return 1.0;
    }

    template <class _Input_Iterator, class FloatType >
    void ks_test( const _Input_Iterator a_begin,
		  const _Input_Iterator a_end,
		  const _Input_Iterator b_begin,
		  const _Input_Iterator b_end,
		  FloatType &d,
		  bool absolute) {
      /* Oh for templated typedefs! */
      typename iterator_traits<_Input_Iterator>::value_type d1(0),d2(0);
      typename iterator_traits<_Input_Iterator>::difference_type j1(0),j2(0),n1(a_end-a_begin),n2(b_end-b_begin);

      /* Check for zero length inputs. */
      if (n1 == 0)
	return;
      if (n2 == 0)
	return;

      FloatType dt;
      FloatType fn1=0.0,fn2=0.0;
      FloatType scale1(FloatType(1.0)/FloatType(n1)),scale2(FloatType(1.0)/FloatType(n2));
      dt=0.0; d=0.0;  
      _Input_Iterator a(a_begin),b(b_begin);
      while (a != a_end && b != b_end ) {
	d1 = *a; d2 = *b;
	if (d1 <= d2 ) {
	  fn1 = scale1*FloatType(j1);
	  ++j1; ++a; 
	}
	if (d2 <= d1 ) {
	  fn2 = scale2*FloatType(j2);
	  ++j2; ++b;
	}
	/* Minor kludge that is the easiest way to manage the Kuiper
	   modification. */
	dt = absolute ? 
	  (fn2 > fn1 ? fn2 - fn1 : fn1 - fn2) /* Unsigned absolute difference. */
	  : 
	  fn2 - fn1;
	if (dt > d)
	  d = dt;
      }
    }
    
    template <typename _Float_Type, typename _Size_Type> 
    _Float_Type &en(_Float_Type &en, _Size_Type n1, _Size_Type n2) {
      en = (_Float_Type(n1)*_Float_Type(n2))/(_Float_Type(n1)+_Float_Type(n2));
      return en;
    }

    template <class _Input_Iterator, class FloatType>
    void kp_test( const _Input_Iterator a_begin,
		  const _Input_Iterator a_end,
		  const _Input_Iterator b_begin,
		  const _Input_Iterator b_end,
		  FloatType &v) {
      FloatType d_plus(0), d_minus(0);
      ks_test(a_begin,a_end,b_begin,b_end,d_plus,false);
      ks_test(b_begin,b_end,a_begin,a_end,d_minus,false);
      v = d_plus + d_minus;
    }

    template <class FloatType>
    FloatType ks_test_p(FloatType d, FloatType en) {
      if (en < 4.0)
	return 0.0;
      return qks((sqrt(en)+0.12+0.11/sqrt(en))*d);
    }


    template <class FloatType>
    FloatType kp_test_p( FloatType v, FloatType en) { 
      return qkp((sqrt(en) + 0.155 + 0.24/sqrt(en))*v);
    }

    namespace wilcoxon {
      template <class NumericVector>
      void cdf(NumericVector &cdf, unsigned n)  {
	typedef typename NumericVector::value_type value_type;
	typedef typename NumericVector::size_type size_type;
	size_type Tmax(n*(n+1)/2);
	cdf.resize(1+Tmax);
	std::fill(cdf.begin(),cdf.end(),value_type(1));
	size_type m(0),m_new(0);
	for (size_type i=1; i<=n; ++i) {
	  m_new = m+i;
	  for (size_type a(m_new),b(m); a>=i+1; --a,--b)  
	    cdf[a-1] = (cdf[a-1] + cdf[b-1])/value_type(2);
	  for (size_type a(1); a<=i; ++a) 
	    cdf[a-1] /= value_type(2);
	  m=m_new;
	}
      }
    }
    
    template <class I>
    void wilcoxon_ci(I begin, I end,
		     double alpha,
		     double &a1, double &b1, double &a2, double &b2, double &med) {
      typedef typename std::iterator_traits<I>::value_type value_type;
      typedef typename std::iterator_traits<I>::difference_type difference_type;
      typedef typename std::iterator_traits<I>::difference_type size_type;
      difference_type n=end-begin;
      std::vector<value_type> cdf; 
      wilcoxon::cdf(cdf,static_cast<unsigned int>(n));
      size_type Tmax=n*(n+1)/2;
      typename std::vector<value_type>::iterator i(std::find_if(cdf.begin(),cdf.end(),std::bind2nd(std::greater_equal<value_type>(),1.0-alpha)));
      difference_type k1 = Tmax - (i-cdf.begin());
      difference_type l1 = Tmax + 1 - k1;
      typename std::vector<value_type>::iterator i2(std::find_if(cdf.begin(),cdf.end(),std::bind2nd(std::greater_equal<value_type>(),1.0-alpha/2.0)));
      difference_type k2 = Tmax - (i2-cdf.begin());
      difference_type l2 = Tmax + 1 - k2;
      std::vector<value_type> ww(Tmax);
      for (difference_type i=1; i<=n; ++i) 
	for (difference_type j=1; j<=i; ++j)
	  ww[(i-1)*i/2 + j - 1] = (*(begin+i-1) + *(begin+j-1))/2.0;
      std::sort(ww.begin(),ww.end());
      
      
      const value_type inf(std::numeric_limits<value_type>::infinity());
      a1=-inf;
      b1=inf;
      a2=-inf;
      b2=inf;
      if (k1 > 0) {
	a1 = ww[k1-1];
	b1 = ww[l1-1];
      }
      
      if (k2 > 0) {
	a2 = ww[k2-1];
	b2 = ww[l2-1];
      }
      std::sort(ww.begin(),ww.end());
      med = ejg::statistics::median(ww.begin(),ww.end());
    }

    template <class I>
    void mann_whitney_wilcoxon(I begin_a, I end_a,
			       I begin_b, I end_b,
			       double &U) {
      /* Pick the smallest range. */
      typename std::iterator_traits<I>::difference_type Na(end_a-begin_a);
      typename std::iterator_traits<I>::difference_type Nb(end_b-begin_b);
      /* Optionally swap the ranges. */
      if (Na > Nb) {
	std::swap(begin_a,begin_b);
	std::swap(end_a,end_b);
      }
      
      /* Iterate over a. */
      unsigned long U_times_two(0);
      for (I ita(begin_a); ita != end_a; ++ita) 
	for (I current(begin_b); current != end_b; ++current) 
	  if (*current < *ita)
	    U_times_two += 2;
	  else if (*current == *ita)
	    U_times_two += 1;
	
      /* Scale U. */
      U = 0.5*U_times_two;		      			 
    }

    template <class I>
    typename std::iterator_traits<I>::value_type rofunc(I x_begin, I x_end,
							I y_begin, I y_end, 
							I tmp_begin, I tmp_end,
							typename std::iterator_traits<I>::value_type b,
							typename std::iterator_traits<I>::value_type &aa,
							typename std::iterator_traits<I>::value_type &abdevt) {	
      typedef typename std::iterator_traits<I>::value_type value_type;
      value_type d,sum(0);
      for (I x(x_begin),y(y_begin),arr(tmp_begin); 
	   x != x_end; ++x,++y,++arr) 
	*arr = *y - b**x;
      std::sort(tmp_begin,tmp_end);
      aa=median(tmp_begin,tmp_end);
      abdevt=value_type(0);
      for (I x(x_begin),y(y_begin);
	   x != x_end; ++x,++y) {
	d=*y-(b**x+aa);
	abdevt += std::abs(d);
	if (*y != value_type(0.0))
	  d /= std::abs(*y);
	if (std::abs(d) > std::numeric_limits<value_type>::epsilon() )
	  sum += (d >= 0.0 ? *x : -*x);
      }
      return sum;
    }





    template <class I>
    void robust_linear_fit(I x_begin, I x_end,
			   I y_begin, I y_end,
			   I tmp_begin, I tmp_end,
			   typename std::iterator_traits<I>::value_type &a,
			   typename std::iterator_traits<I>::value_type &b,
			   typename std::iterator_traits<I>::value_type &abdev,
			   bool is_a_fixed) {
      typedef typename std::iterator_traits<I>::difference_type difference_type;
      typedef typename std::iterator_traits<I>::value_type value_type;
      value_type bb,b1,b2,del,f,f1,f2,sigb,temp;
      value_type sx(0),sy(0),sxy(0),sxx(0),chisq(0);
      value_type aa(0),abdevt(0);
      value_type n_data(x_end-x_begin);
      for (I x(x_begin),y(y_begin); x != x_end; ++x,++y) {
	sx += *x; sy += *y;
	sxy += *x**y; sxx += *x**x;
      }
      del = value_type(n_data)*sxx-sx*sx;
      aa=(sxx*sy-sx*sxy)/del;
      bb=(n_data*sxy-sx*sy)/del;
      for (I x(x_begin),y(y_begin); x != x_end; ++x,++y) {
	chisq += (temp=*y-(aa+bb**x),temp*temp); // BUG?
      }
      sigb=std::sqrt(chisq/del);
      b1=bb;
      f1=rofunc(x_begin,x_end,y_begin,y_end,tmp_begin,tmp_end,b1,aa,abdevt);
      if (is_a_fixed)
	aa=a;
      if (sigb > value_type(0)) {
	b2=bb+sign(value_type(3)*sigb,f1);  // TODO
	f2=rofunc(x_begin,x_end,y_begin,y_end,tmp_begin,tmp_end,b2,aa,abdevt);
	if (is_a_fixed)
	  aa=a;
	if (b2 == b1) {
	  if (!is_a_fixed)
	    a=aa; 
	  b=bb;
	  abdev=abdevt/n_data;
	  return;
	}
	while (f1*f2 > value_type(0)) {
	  bb=b2+1.6*(b2-b1);
	  b1=b2; f1=f2; b2=bb;
	  f2=rofunc(x_begin,x_end,y_begin,y_end,tmp_begin,tmp_end,b2,aa,abdevt);
	  if (is_a_fixed)
	    aa=a;
	}
	sigb=0.01*sigb;
	while (absdiff(b2,b1) > sigb) {
	  bb=b1+value_type(0.5)*(b2-b1);
	  if (bb == b1 || bb == b2) break;
	  f=rofunc(x_begin,x_end,y_begin,y_end,tmp_begin,tmp_end,bb,aa,abdevt);
	  if (is_a_fixed)
	    aa=a;
	  if (f*f1 >= 0.0) {
	    f1=f; b1=bb; 
	  } else {
	    f2=f; b2=bb;
	  }
	}
      }
      a=aa; b=bb;
      abdev=abdevt/n_data;
    }

    
	
  
  
    
  } }


//
// $Log: statistics.cpp,v $
// Revision 1.3.2.1  2009/07/20 14:18:06  graceej
// * Modifications to compile under MSVC
//
// Revision 1.3  2009/07/20 09:07:45  graceej
// * Added undefs to prevent errors when compiling under Windows.
// * Carried out explicit static cast.
// * Addded missing include.
//
// Revision 1.2  2009/07/18 14:26:56  graceej
// * Weeded the code to smarten up its layout and remove unwanted functions.
// * Brought over these changes to the HEAD branch.
// * Prepare for upload of timer to boost vault.
//
// Revision 1.1.2.1  2009/07/17 18:21:12  graceej
// * Reorganised code so that the directory structure matches the namespace structure.
//
// Revision 1.11  2009/07/08 18:30:28  graceej
// * Reviewing code and correcting.  The intercept is likely to be a meaninless parameter and should be ignored.
//
// Revision 1.10  2009/06/30 15:21:01  graceej
// * Add a first draft of the Mann-Whitney-Wilcoxon rank test.
//
// Revision 1.9  2009/03/20 15:09:50  graceej
// * Corrected bug in calculation of averge deviation.
//
// Revision 1.8  2009/03/19 20:12:50  graceej
// * Added robust linear fitting.
//
// Revision 1.7  2009/03/17 22:39:40  graceej
// * Minor bug fix.
// * Improved documentation.
// * Concrete example of useage to determine confidence limits.
//
// Revision 1.6  2009/03/17 21:32:23  graceej
// * Added wilcoxon signed rank test to return confidence intervals for paired differences.
//
// Revision 1.5  2009/02/05 20:37:55  graceej
// * Working.
//
// Revision 1.4  2009/01/16 10:48:50  graceej
// * Rename functions and add more documentation.
//
// Revision 1.3  2009/01/12 16:46:25  graceej
// * First release, tagged as timer-release-1_0_0
//
//
