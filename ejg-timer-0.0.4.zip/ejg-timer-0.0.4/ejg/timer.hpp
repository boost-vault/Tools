#ifndef _EJG_TIMER_HPP_
#define _EJG_TIMER_HPP_

//
//          Copyright Edward J. Grace 2008 - 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//

// CVS Information.
//
// $Author: graceej $ $Date: 2009/07/20 12:52:10 $
// $Revision: 1.4.2.2 $
//

#include <ctime>      // For clock() and clock_t
#include <vector>     // For various buffers.

/**
 * @file   timer.hpp
 * @author Edward Grace <edward.grace@gmail.com>
 * @date   Fri Jul 17 10:46:34 BST 2009
 * 
 * @brief Time functions in a statistically meaningful and robust manner.
 */

/**
 * \mainpage A robust function timer
 *
 * This proposed function performance timing library is intended to be
 * suitable for answering the question "Which is faster function foo
 * or function bar?" with a well defined and statistically sound
 * basis.
 *
 * For most people all they are ever likely to need is the constructor
 * and the relative timing member function.
 *
 *
 */

namespace ejg {

  namespace ticks {
    /** 
     * @brief A kludge to parameterise the type representing the
     * difference of two potentially opaque times. 
     *
     * Currently this is hard-wired to be of type double, however
     * there is no requirement for this.  
     * 
     * @todo A permanent cross-platform solution to this should be
     * implemented.
     */    
    typedef double difference_type;

    /** 
     * @brief A default function for returning the difference between
     * two default time types. These are clock_t.
     * 
     * @param a The first time.
     * @param b The second time.
     * 
     * @return The number of ticks between b and a.
     */
    ejg::ticks::difference_type default_elapsed(clock_t t1,clock_t t0) {
      return ejg::ticks::difference_type(t1-t0);
    }
  }
  

  /** 
   * @brief A comprehensive result structure returned from
   * basic_timer::measure_execution_time(). 
   *
   * This is a straightforward vanilla C-like structure holding
   * comprehensive information about the result of a call to
   * measure_execution time.
   */
  struct timer_result_type {
    unsigned long iterations_per_atom; /**< The number of times to
					  call the function to be
					  timed in each atom (timing
					  block). */
    ticks::difference_type raw_atom_median,/**< The median number of ticks to
					      execute one atom of calls. */
      raw_atom_max,		/**< The maximum number ticks observed
			   during the last buffer. */
      raw_atom_min,		/**< The minimum number of ticks
			   observed during the last buffer. */
      raw_atom_global_max,	/**< The global maximum number of
			   ticks observed for executing one
			   atom of iterations. */
      raw_atom_global_min,	/**< The absolute minimum number of
			   ticks observed. */
      count_calls,		/**< A count of the number of times
				   the function to measure was
				   called. */
      measure_execution_self_time; /**< The number of ticks required
				      to execute a call to
				      chrono(). */
    double median,		/**< The median time for a single
				   function call. */
      median_delta,		/**< The minimum possible standard
				   error in the median. This is in
				   effect simply measured median
				   divided by the inverse
				   precision. The median may well have
				   a greater error than this.  This
				   should be considered a lower bound
				   on the error. */
      max,			/**< The maximum time taken to execute
				   a single function call observed
				   during one buffer-full of
				   samples. */
      min,			/**< The minimum time taken to execute
				   a single function call observed
				   during one buffer full of
				   samples. */
      global_max,		/**< The largest time observed while
				   measuring the function.*/
      global_min;		/**< The smallest time observed while
				   measuring the function. */
    double t_c,		        /**< The overhead of calling the
				   clock. */
      delta,			/**< The non-clock overhead. */
      epsilon,			/**< The variation of the overhead. */
      d;			/**< The value of the statistic used
				   to test for a stationary
				   probability distribution. */
    double nominal_target_precision_percent, /**< The expected target
						precision
						(percent). */
      estimated_actual_precision_percent; /**< The actual target
					     precision. */
  };


  /** 
   * @brief A template timer for robust measurement of function speed.
   *
   * Timing the execution of a function call to gain a representative
   * idea of how fast it is, either in absolute terms or - more
   * meaningfully relative to another function is less straightforward
   * than it initially appears.  
   * 
   * Basing measurements on a robust measure of central tendency, such
   * as the median, is essential but only half the problem. In order
   * to be confident that the median is meaningful we have to be
   * confident that we have collected enough data to reasonably
   * represent the underlying, and possibly non-stationary,
   * probability distribution.  When measuring the time we are in
   * principle drawing samples (times) from a long-tailed probability
   * distribution with a well defined minimum cutoff - but no
   * fundamental upper limit.
   *
   * The first problem is: "How can we have confidence that we have
   * observed enough data to justify estimating the central
   * tendency?".
   *	 	 
   * The proposed technique used here, is to make use of the
   * two-sample Kolmogorov-Smirnov test to determine when a sampled
   * empirical cumulative distribution function (CDF) is
   * self-consistent.  Self-consistency in this context occurs when
   * the differences between two interleaved samples of the underlying
   * CDF are so small that they are unlikely to have occurred due to
   * chance alone. Since we are only extracting the median time from
   * such a sub-sampled distribution rather than some other
   * percentile, the result should be a good estimate of the true
   * underlying median value.  
   *
   * This is far from foolproof!  As usual we cannot say \em for \em
   * certain that the observed empirical cumulative distribution
   * function represents the \em real distribution function.  Indeed
   * we cannot even be certain there is a (stationary) probability
   * density function.  What we can say, is that until the thresholds
   * are breached the sampled empirical distribution function is \em
   * probably \em not representative of the real function.
   *
   * By default the abstract timer class uses the standard clock()
   * function which is a very slow timer, typically with a ten
   * millisecond tick frequency. Consequently requiring high precision
   * and confidence from this timer will require very long observation
   * times. In practice using the built-in clock() function for
   * anything other than crude timing of slow functions will be
   * impractical.
   *
   * On many platforms a simple timer fabricated from a call to
   * gettimeofday() will suffice to yield multi-microsecond accuracy.
   *
   * For quick, highly precision timing getticks() from cycle.h in the
   * FFTW project is a good alternative.
   */   
  template <typename ticks = clock_t,typename ticks_wall = clock_t>
  class generic_timer {
  protected:
    /** 
     * @brief A typedef for a void function pointer that we wish to
     * time. Perhaps this should be a functor.
     * 
     */    
    typedef void (*void_function_type)(void);
    /** 
     * @brief A typedef that simply resolves to the template parameter
     *        type for the ticks.
     */
    typedef ticks ticks_type;

    /** 
     * @brief The function type representing the high precision clock,
     * which should return a value of ticks_type.
     */
    typedef ticks_type (*fast_chrono_function_type)(void);

    /** 
     * @brief The function type representing a function for taking the
     * difference of two opaque times.
     */
    typedef ejg::ticks::difference_type (*fast_chrono_difference_function_type)(ticks_type,ticks_type);

    /**
     * @brief The function type representing the low precision clock,
     * which should return a value of ticks_wall type.
     */
    typedef ticks_wall (*wall_chrono_function_type)(void);

    /**
     * @brief A type representing internal counters, this should be at
     * least unsigned long.  It is the type used for all counters of
     * iterations.
     */
    typedef unsigned long counter;

    /**
     * @brief The type of function object to be timed by the timer, a
     * unary function object that takes no arguments (void) and
     * returns nothing (void).
     */
    //    typedef std::unary_function<void,void> function_type;


    /** 
     * @brief Convert a time from raw observed ticks to the nominal
     * function execution time.
     * 
     * @param value The number of ticks 
     * 
     * @brief The nominal execution time.
     */   
    double rescale_atom(ejg::ticks::difference_type value) 
    { return scale*value - scale*get_chrono_overhead(); }

    /** 
     * @brief The type corresponding to buffer sizes.
     */
    typedef typename std::vector<ejg::ticks::difference_type>::size_type size_type;
    /**
     * @brief A type used to represent iterators over vectors of times. 
     */
    typedef typename std::vector<ejg::ticks::difference_type>::iterator iterator;
    /** 
     * @brief Default vector type. 
     */
    typedef std::vector<double> vector;
    /**
     * @brief The high precision chronometer. 
     * @todo I would like this to be const, but it prevents MSVC from
     * building a default assignment constructor.  For now drop the
     * constness.
     */
    fast_chrono_function_type chrono;

    /** 
     * @brief A function pointer to something that can take the
     * difference of two possibly opaque absolute time types and
     * return a sane result.
     * @todo This is a result of a kludge required to make the timer
     * work on windows, which typically uses a union type for the high
     * precision counters.
     * @bug Sanely treat the plugin of a chronometer type.  Perhaps
     * the design of this needs to be thought of in terms of lessons
     * learned from boosts util::high_precision_timer.
     */
    fast_chrono_difference_function_type chrono_difference;
    
    /**
     * @brief The low precision chronometer.
     * @todo I would like this to be const, but it prevents MSVC from
     * building a default assignment constructor.  For now drop the
     * constness.
     */
    wall_chrono_function_type chrono_wall;

    /**
     * @brief A scale to convert differences in chrono_wall values in
     * to actual seconds.
     * @todo I would like this to be const, but it prevents MSVC from
     * building a default assignment constructor.  For now drop the
     * constness.
     */
    double chrono_wall_scale; /**< The scaling between wall
				 clock time and the slow
				 wall-clock timer. */

    double chrono_scale;	/**< @todo Document chrono_scale, is
				   it the scaling between the wall
				   clock and the fast chronometer. */

    double alpha;		/**< The rejection probability used in
				   the Wilcoxon signed rank test and
				   other confidence bounds. */

    vector t_a;			/**< Contains median times for
				   function a used in Wilcoxon signed
				   rank test. */

    vector t_b;                /**< Contains median times for
				   function b used in Wilcoxon signed
				   rank test. */

    vector z;			/**< Differences used in Wilcoxon signed rank test.  */

    size_t batch;		/**< The number of times to do in a
				   row for the infinity timing
				   test. */
    vector xs;			/**< Recorded effective iteration count. */

    vector ys;			/**< Times per iteration. */

    vector residuals;		/**< Residuals of the linear model fit to xs and ys. */

    vector tmp;			/**< A temporary buffer used for the linear fit. */

    counter calibration_loop_count; /**< A count of the number of the
				       number of attempts taken to
				       calibrate the high precision
				       clock overhead. */

    bool is_timeout;		/**< True if the last
 				   measure_execution timed out.  */

    double alpha_d;		/**< Threshold for the KS statistic. */

    double max_time_seconds;	/**< Timeout limit for
				   measure_execution_time. */

    timer_result_type r;        /**< The comprehensive result of the
				   last measure_execution_time. */

    double nominal_precision_target;	/**< The ideal target nominal precision. */

    counter max_attempts_for_nominal_precision_target; /**< The maximum number of
							  attempts to try and
							  find the minimum number
							  of ticks for the given
							  precision before giving
							  up. */

    size_type buffer_length;	/**< The length of each buffer of
				   samples. */

    size_type n_samples;	/**< The number of sample. */

    double scale;		/**< The scaling between atom time and mean time. */

    std::vector<ejg::ticks::difference_type> samples_raw; /**< The unsorted interleaved
							     buffer of samples. */
    
    std::vector<ejg::ticks::difference_type> samples_srt; /**< The sorted interleaved buffer
							     of samples.  */
    bool is_samples_double_up_to_date; /**< Used to check the state of
					  the double precision list of
					  samples.  */
    std::vector<double> samples_double;  /**< A buffer for generating
						    a convenience set of
						    double times.  */

    vector samples_double_re; /**< Re-sampled version of
				 samples_double.  */

    vector medians; /**< Used for generating confidence limits on the
				    medians. */

    double overhead_clock,	/**< The overhead in calling the
				   clock. */

      overhead_other,		/**< @todo Remove this.  Other
				   iteration independent overhead.  */

      overhead_spread;		/**< The uncertainty in the
				   overhead. */

    counter measure_execution_time_counter; /**< A count of the number
					       of times
					       measure_execution_time()
					       has been called. */

    bool is_paranoid;		/**< @todo Remove this.  If true the
				   order of the function calls in
				   relative measurements will be
				   randomised to avoid potential gross
				   biasing interference effects. */

    void_function_type f_a;	/**< The first function to time. */

    void_function_type f_b;	/**< The second function to time. */

    counter measure_calls_counter; /**< A count of the number of times
				      the function to measure was
				      called. */

    counter iterations_per_atom;	/**< Number of iterations for atom. */


  public:
    /** 
     * @brief Construct a timer object using a high precision timer
     * and a low precision timer.
     *
     * When constructing a timer object you should supply the timer
     * function, which should be a function with no arguments as the
     * first argument to the constructor.  The corresponding first
     * template type should be the type of the ticks returned by this
     * function.  It is important not to think that using double or
     * float is sufficient since these have insufficient precision.
     * You must be able to subtract two times differing by, say, \f$
     * 10^{-30}\f$ since the absolute value returned by the timer can
     * be very large, for example the number of microseconds since
     * midnight 1st of January 1970.
     *
     *
     * The high precision timer is \em not assumed to be an accurate
     * timer, it can exhibit jitter noise and a systematic offset.
     *
     * @param high_precision A high precision timer function, by
     * default this uses the standard (low precision) clock()
     * function. 
     *
     * @param low_precision A low precision timer function, by default
     * this uses the standard clock() function.
     *
     * @param clocks_per_sec The scale between the low precision clock
     * ticks and the actual wall clock time in seconds. This can be
     * used to cross-calibrate the high precision timer to return
     * times in seconds.
     * @todo Add a requirement for a function that will subtract two
     * tick times and set that to a sensible default for the
     * std::clock.
     */
    explicit generic_timer(const fast_chrono_function_type &high_precision = std::clock,
			   const fast_chrono_difference_function_type &high_precision_difference = ejg::ticks::default_elapsed,
			   const wall_chrono_function_type &low_precision = std::clock, 
			   ticks_wall clocks_per_sec = CLOCKS_PER_SEC);
    
    /** 
     * @brief Calibrate the overhead inherent in calling the high
     * precision timer in units of clock ticks.
     *
     * When timing functions that are of similar execution scale to
     * the timer overhead it is important to account for this overhead
     * - otherwise large relative differences in speed between two
     * functions will not be observed.
     *
     * Calibration of the clock overhead is absolute, in other words
     * not measured with respect to anything else. Consequently if the
     * machine is undergoing significant changes in the execution
     * environment while the calibration is taking place there is a
     * possibility that the clock overhead can be significantly over
     * estimated. 
     *
     * @todo Explain how this works and its assumptions.
     * @see get_chrono_overhead()
     * @see get_chrono_sigma()
     * @see calibrate_seconds()
     * @see measure_infinity_time()
     */
    void calibrate_chrono_overhead();

    /** 
     * @brief Reset the chronometer overhead back to its initial state
     * before calibration.
     */    
    void reset_chrono_overhead() {
      overhead_clock = 0.0; 
      overhead_other = 0.0;
      overhead_spread = 0.0; 
    }

    /** 
     * @brief Calibrate the (assumed linear) mapping between wall
     * clock time and the high precision timer.
     *
     * @todo Explain the assumptions in this.
     * @see calibrate_chrono_overhead()
     * @see seconds()
     * @see milliseconds()
     * @see microseconds()
     * @see nanoseconds()
     */
    void calibrate_seconds();


    /** 
     * @brief Estimate the large iteration limit execution time of a
     * function.
     *
     * For this to be meaningful, for fast functions, the clock
     * overhead should have been calibrated.  By no means should this
     * be interpreted as any kind of confidence interval estimate of
     * the execution time - it is not.  The function is simply
     * repeatedly timed with a monotonically increasing iteration
     * count.  
     *
     * The observed times should be reasonably linear with respect to
     * this.  There will be small differences from this linearity -
     * these are indicative of interference between the number of
     * clock cycles in the loop and the overhead taken to call the
     * clock.
     *
     * These small differences are characterised by the median
     * absolute deviation (MAD) of the residuals to the linear
     * fit. This MAD should not be considered to be a confidence limit
     * on the slope - it is not.  
     *
     * Care should be taken with absolute timings of this nature.  If
     * the machine is not quiescent so that this process is
     * overwhelmingly dominant the timing will not be repeatable.  If
     * you wish to determine which function is faster than another in
     * a repeatable and robust way you should not use this method to
     * time two separate functions.
     * 
     * @todo Does this explain correctly the assumptions.
     * @param f The function to be timed.
     * @param t The best estimate of the observed time.
     * @param intercept The intercept of the (assumed) linear fit.
     * @param mad The median absolute deviation around this time.
     * @param m_offset An offset in the number of iterations.  When
     * used to time the timer this should (strictly) be set to 1 since
     * there is (approximately) one more execution of the timer
     * function than would be expected. When the clock has been
     * appropriately calibrated this should be zero.
     */
    template <class _Operation>
    void measure_infinity_time(_Operation f, 
			       double &t, 
			       double &intercept,
			       double &mad,
			       size_t m_offset = 0);
    /** 
     * @brief Estimate confidence limits of the percentage speedup of
     * function b relative to function a. 
     * 
     * This function determines a confidence limit on the relative
     * speed of a function \f$ f_a\f$ relative to a function \f$
     * f_b\f$.  If the confidence interval straddles zero then one
     * cannot claim that the speed of the two functions differ. To
     * discriminate between them you must increase the nominal
     * precision of the measurement and potentially calibrate the
     * overhead inherent in calling the clock.
     *
     * The execution time of \f$ f_b\f$ relative to \f$ f_a\f$ is
     * defined as:
     *
     *    \f[ s = \frac{\tau_a - \tau_b}{\tau_a}, \f]
     *
     * where \f$ \tau_{a,b}\f$ is the observed time for function \f$
     * f_{a,b}\f$. Positive values indicate that \f$ f_a\f$ is faster
     * than \f$ f_b\f$.
     *
     * The confidence interval is determined by applying the Wilcoxon
     * signed rank test to the differences of the logarithms of the
     * times. Letting \f$ A = \log \tau_a \f$, \f$ B = \log \tau_b \f$
     * and \f$ z = A - B \f$ the speedup percentage, and the
     * confidence intervals, is given by 
     *
     *    \f[ s_{\%} = 100 \left\{\exp z - 1 \right\}. \f]
     *
     * The paired measurements are carried out for identical numbers
     * of iterations.  It is technically possible for the faster
     * function to be slower for a given number of iterations. This
     * tests if the differences are statistically significant. The
     * significance level is set by set_alpha().  At the significance
     * level is improved more measurements must be taken.  The
     * default, for an \f$ \alpha=0.05 \f$ is 6, one more than
     * strictly required.
     *
     * When running under intermittent load this can, from
     * time-to-time, return confidence intervals that span a large
     * range, for example [-50,10,10.1]% where the central value is
     * the median, while usually returning far more confined results -
     * e.g. [9.9,10,10.1]%.  This will probably be due to a significant
     * intermittent change in the machine loading while measuring
     * function a and b, resulting in an over (or under) estimate of
     * the time.  This should not be considered a bug, it's real, for
     * that instance you simply cannot state (at the 95% confidence
     * interval) that one function is faster than the other.  If one
     * had just been conducting a point estimate comparison, you could
     * easil10y have seen one function be 50% slower than the other and
     * form an incorrect conclusion.  Instead, due to the wide
     * confidence band that straddles zero, you could re-time the
     * functions with an increased precision until the confidence
     * interval did not straddle zero.
     *
     *
     * @see get_alpha_percentage_speedup()
     * @param fa The first function, functor.
     * @param fb The second function, functor. 
     * @param MedPercent The nominal median point estimate of the
     * percentage speedup of a relative to b.
     * @param MinPercent The lower bound of the nominal 95.4 confidence limit.
     * @param MaxPercent The upper bound of the nominal 95.4 confidence limit.
     *
     * @todo Add a new function that measures the percentage speedup
     * relative to a previously measured function a.
     */
    template <class _OperationA, class _OperationB>
    void measure_percentage_speedup(_OperationA fa,
				    _OperationB fb,
				    double &MinPercent,
				    double &MedPercent,
				    double &MaxPercent);


    /** 
     * @brief Measure the execution time of the nullary function f.
     *
     * Given a function object with an operator() method that takes no
     * arguments (nullary functor) or a pointer to a function taking
     * no arguments this method attempts to robustly measure the
     * absolute execution time of the function within the nominal
     * precision set by set_nominal_precision_target_percent().
     *
     * If the high precision clock has been calibrated, the returned
     * time is adjusted to account for the clock overhead. Similarly,
     * with the clock jitter known, a better estimate of the nominal
     * precision is obtained.
     *
     * @param f The nullary function object / function pointer.
     * 
     * @return The number of high precision clock ticks (possibly
     * fractional) that it takes to execute f().
     */
    template <class _Operation>
    double measure_execution_time(_Operation f);

    /** 
     * @brief Measure the execution time, placing the results in the
     * timer result structure.
     *
     * @todo Check that the use of the iterations_per_atom is
     * consistent and correctly being reset when it should be.
     * 
     * @param f The nullary function to measure. 
     * @param result A reference to the comprehensive result type.
     * 
     * @return A reference to the result type.
     */    
    template <class _Operation>
    timer_result_type &measure_execution_result(_Operation f,
						 timer_result_type &result);

    /** 
     * @brief Smooth bootstrap confidence interval for the last point
     * estimate of the median time.
     *
     * By smoothed bootstrap re-sampling of the values used to
     * determine the last point estimate of the median execution time,
     * typically from measure_execution_time() one can obtain a
     * confidence bound on the estimate.
     *
     * Typically this confidence interval is very narrow, since the
     * median is a discrete statistic, it could be so fine that the
     * true confidence bounds are within this discretisation.
     *
     * @deprecated This member function is unlikely to serve any
     * useful purpose for an end user.  All it does is demonstrate
     * that the median is a robust estimate of central tendency.  It
     * will be removed in future versions. If someone wished to
     * re-introduce it, they can do so by deriving from this base
     * class and making use of the protected members.
     * @param min A reference to the lower 95.4% confidence interval.
     * @param median A reference to the median median.
     * @param max A reference to the upper 95.4% confidence interval.
     */
    void measure_execution_time_confidence_bounds(double &min, 
						  double &median, 
						  double &max);
    /** 
     * @brief Set the minimum nominal precision, in percent, for timings.
     *
     * When timing a function, sufficient numbers of iterations must
     * be carried out so that the precision and potential jitter on
     * the clock has negligible effect on the result.  This indirectly
     * controls the number of iterations that are carried out in a
     * timing atom.
     * 
     * @see get_nominal_precision_target_percent()
     * @param percent The required percentage nominal precision.
     */
    void set_nominal_precision_target_percent(double percent) 
    { nominal_precision_target=percent; }

    /** 
     * @brief Get the minimum nominal precision, in percent, for timings.
     * 
     * @see set_nominal_precision_target_percent()
     * @return The prevailing required percentage nominal precision.
     */
    double get_nominal_precision_target_percent() const 
    { return nominal_precision_target; }


    /** 
     * @brief Get the maximum length of wall clock time in (nominal)
     * seconds allowed for measure the execution time of a target
     * function.
     * 
     * For low precision timers the time limit needs to be very large
     * since we must observe the function for a long time in order to
     * obtain sufficient precision.
     * 
     * If set to zero or a negative number no time limit is imposed.
     * In order for this to really represent seconds you must give the
     * correct value of clocks_per_sec to the constructor so that the
     * wall clock function can measure actual seconds.
     * 
     * @see set_timeout()
     * @brief The time limit in seconds.
     */
    double get_timeout() const
    { return max_time_seconds; }


    /** 
     * @brief Set the timeout in seconds, allowed for any single point
     * estimate of the time.
     *
     * When applied to a single point estimate of the time such as a
     * call to measure_execution_time() the function will return a
     * result within this many seconds.
     * 
     * @see get_timeout()
     * @param t The maximum timeout time.
     */    
    void set_timeout(double t) 
    { max_time_seconds = t; }


    /** 
     * @brief Get the anticipated uncertainty on calling the clock.
     * 
     * @return Return an estimate of the standard deviation of
     * execution time of a single call to the clock in chronometer
     * units.
     */
    double get_chrono_sigma() const
    { return overhead_spread; }

    /** 
     * @brief Return the point estimate in calling the clock.
     *
     * @return A point estimate of how long it takes to carry out one
     * call of the high precision clock.
     */    
    double get_chrono_overhead() const 
    { return overhead_clock; }

    /** 
     * @brief Translate a time in ticks to a time in seconds.
     *
     * This function requires that the clock has been calibrated and
     * the wall clock has been calibrated. If they have not been
     * calibrated then the returned result is undefined.
     *
     * @see calibrate_seconds() 
     * @see milliseconds()
     * @see microseconds()
     * @param t The time in clock ticks.
     * 
     * @return The time in seconds.
     */
    double seconds(double t) {
      return chrono_scale*t;
    }

    /** 
     * @brief Convert a time in clock ticks to milliseconds.
     * 
     * @param t The time in ticks.
     * 
     * @return The time in milliseconds.
     * @see calibrate_seconds() 
     * @see seconds()
     * @see microseconds()
     * @see nanoseconds()
     */
    double milliseconds(double t) {
      return seconds(t)*1000.0;
    }

    /** 
     * @brief Convert a time in clock ticks to microseconds.
     * 
     * @param t The time in clock ticks.
     * 
     * @return The time in microseconds.
     * @see calibrate_seconds() 
     * @see seconds()
     * @see milliseconds()
     * @see nanoseconds()
     */    
    double microseconds(double t) {
      return milliseconds(t)*1000.0;
    }

    /** 
     * @brief Convert a time in clock ticks to a time in nanoseconds.
     * 
     * @param t The time in clock ticks.
     * 
     * @return The time in nanoseconds.
     * @see calibrate_seconds() 
     * @see seconds()
     * @see milliseconds()
     * @see microseconds()
     */
    double nanoseconds(double t) {
      return microseconds(t)*1000.0;
    }

    /** 
     * @brief Set the alpha (confidence interval) for the
     * measure_percentage_speedup() method.  
     *
     * The confidence interval returned by the method
     * measure_percentage_speedup() is given by this parameter.
     * By convention the value is 0.05, corresponding to a returned
     * confidence interval of 95%. 
     *
     * Increasing this parameter to, for example, 0.1 will reduce the
     * number of measurements required by the relative execution time
     * method, at the expense of decreasing the confidence interval to
     * 90%.  This will typically reduce the range of the returned
     * values, but at the expense of less confidence in them.
     */
    void set_alpha_percentage_speedup(double alpha);

    /** 
     * @brief Get the current value of alpha used in the determination
     * of the confidence interval of the relative execution time.
     * 
     * @return The prevailing value of alpha.
     */    
    const double &get_alpha_percentage_speedup() const 
    { return alpha; }

    /** 
     * @brief The probability that the empirical CDFs differ purely by
     * chance.
     *
     * When determining if we have observed a sufficient number of
     * samples to calculate a representative median we measure the
     * maximum deviation of the two cumulative distribution functions
     * of the acquired times.
     *
     * The distance between the observed CDFs can differ by a given
     * amount purely by chance.  In order to reject the notion that
     * difference is by chance, hence reject the notion that the CDFs
     * are the same the observed p value should be less than this
     * alpha value for a 1-alpha confidence interval.
     *
     * @return The prevailing value of alpha used to reject the notion
     * that the CDFs are the same.
     * @see measure_execution_time()
     * @see set_alpha_ks()
     * @see set_alpha_relative_execution_time()
     */
    double get_alpha_ks() const 
    { return alpha_d; }

    /** 
     * @brief Set the threshold for accepting the samples as being
     * from the same distribution as itself.
     *
     * @todo How large should the buffer be?
     * @see set_alpha_relative_execution_time()
     * @see measure_execution_time()
     * @see get_alpha_ks()
     */
    void set_alpha_ks(double t) 
    { alpha_d = t; }

    /** 
     * @brief Report on the total sample size of the last measurement.
     *
     * When measure_execution_time() is called, enough individual
     * point measurements are taken until the empirical CDF is assumed
     * to be consistent.  This number can vary quite substantially
     * from call to call, depending, amongst other things, on the
     * background tasks on the machine.
     * 
     * @return The number of measurements in the total set of
     * interleaved samples.
     */    
    counter get_total_sample_size() const 
    { return n_samples*2; }

  protected:
    /** 
     * @brief Override the chronometer sigma value.
     * 
     * @param sigma The value, in clock ticks, to assume for the
     * standard deviation of the execution time of a single call to
     * the clock.
     */    
    void set_chrono_sigma(double sigma) 
    { overhead_spread = sigma; }

    /** 
     * @brief Calculate the nominal precision of the product of a time
     * and number of iterations.
     * 
     * @param m_times_tau_m The product of the number of iterations
     * \f$ m\f$ and the observed average time for \f$ m\f$
     * iterations \f$ \tau_m\f$.
     *
     * Assume that the maximum overhead due to calling the clock will
     * be:
     *
     * \f[ \mathrm{max}(t_o) = t_c + \sigma_c \f]
     *
     * where \f$ t_c\f$ is the estimated clock overhead and
     * \f$\sigma_c\f$ is the estimated (iteration dependent) jitter on
     * this overhead.
     *
     * For a given number of iterations \f$ m\f$ where the observed
     * time is \f$\tau_m\f$, an estimate of the fractional precision
     * is given by.
     *
     * \f[ p = \frac{1 + \sigma_c}{m \tau_m  - (t_c + \sigma_c)} \f] 
     *
     * Since the clock cannot be better than \f$ \pm 1 \f$ tick, plus
     * the observed jitter - which may be considerably smaller than 1
     * in the case of a low precision clock, or (confusingly) much
     * larger than 1 in the case of a high precision clock.
     *
     * @brief The nominal precision in percent with the current
     * assumed values of the clock overhead.
     */
    double get_nominal_precision_percent(ejg::ticks::difference_type m_times_tau_m);
    
    
  protected:
    /** 
     * @brief Estimate the number of iterations in the timing loop for
     * a given required percentage precision.
     *
     * In order to achieve a given level of precision we must time
     * enough iterations that the elapsed time exceeds a given
     * minimum.  This function estimates the number of iterations
     * required to reach this goal. This is carried out relative to
     * our estimation of the uncertainty of the clock.
     * 
     * @param f The functor / function pointer to consider.
     *
     * @brief The number of iterations required in an atom to reach
     * at least the prevailing nominal precision.
     */
    template <class _Operation>
    counter estimate_atom_iterations( _Operation f);

    /** 
     * @brief Time the function f a given number of times.
     *
     * Since the timer precision may be significantly lower than the
     * time taken to call a function we actually time an "atom", a
     * given number of iterations of the function call.  
     * 
     * @param f The function to be timed.
     * 
     * @brief The time in ticks taken to execute the atom.  If there
     * is an unresolvable problem with the timing this throws an
     * exception.
     */
    template <class _Operation>
    ejg::ticks::difference_type time_raw_atom( _Operation f); 


    /** 
     * @brief Return the capacity of the internal sample buffer.
     * 
     * @brief The capacity.
     */    
    const size_type get_capacity() const 
    { return buffer_length; }

    /** 
     * @brief The maximum buffer size used for accruing samples.
     * 
     * When accruing samples we do not assume arbitrary storage,
     * instead the buffer is overwritten in a circular manner.  
     * 
     * @param size The required buffer size.
     * 
     * @brief A constant reference to the required buffer size.
     */
    void resize(size_type size) {
      buffer_length = size; 
      samples_raw.resize(buffer_length + buffer_length);
      samples_srt.resize(buffer_length + buffer_length);
      is_samples_double_up_to_date = false;
      samples_double.resize(buffer_length + buffer_length);
      samples_double_re.resize(buffer_length + buffer_length);
    }    

    /** 
     * @brief Access the sorted samples.
     * 
     * 
     * @brief A constant reference to the buffer of sorted samples.
     */
    const std::vector<ejg::ticks::difference_type>& sorted() const 
    { return samples_srt; }

    /** 
     * @brief Return a reference to the measured times. 
     * 
     * @return A constant reference tot he measured times.
     */    
    const std::vector<double>& times() 
    { if (!is_samples_double_up_to_date)
	rescale();
      return samples_double; }

    /** 
     * @brief Return a reference to the re-sampled median data.
     * 
     * 
     * @brief A const reference to the re-sampled medians.
     */
    const std::vector<double>& resampled_medians() const 
    { return medians; }

    /** 
     * @brief Set the size of the re-sampling buffer for determination
     * of the confidence parameters.
     * 
     * @param size The required size.
     */    
    void bootstrap_resize(size_type size) 
    { medians.resize(size); }

    /** 
     * @brief Return the comprehensive result of the last call to
     * measure_execution_time().
     * 
     * @brief A reference to the result structure.
     */
    timer_result_type const &last_result() const 
    { return r; }
    
    /** 
     * @brief Monitor the number of times measure_execution_time() has
     * been called.
     * 
     * @brief A constant reference to the counter.
     */    
    counter const &measure_execution_time_count() const 
    { return measure_execution_time_counter; }
    
    /** 
     * @brief Apply the Wilcoxon test to the relative execution times.
     * 
     * @param MinPercent Minimum percentage speedup.
     * @param MedPercent Median percentage speedup.
     * @param MaxPercent Maximum percentage speedup.
     */
    void wilcoxon_confidence_bounds(double &MinPercent,
				    double &MedPercent,
				    double &MaxPercent);

  protected:
    /** 
     * @brief Rescale the times to generate the scaled double
     * precision representations of the time taken for each iteration.
     */
    void rescale();


  };

    
    
  /**
   * @brief By default the default timer class is a generic_timer that
   * uses clock() for both the high precision and low precision
   * timers.
   */
  typedef generic_timer<> crude_timer;

}

/* Include the compilation unit. */
#include <ejg/timer.cpp>

/**
 * \example example_timer.cpp
 *  @todo Collect together examples of usage in one place.
 *  @brief This is an example of how to use the generic_timer class.
 * 
 * This example shows how to time a pair of similar functions using a
 * chronometer.  
 */

#endif /* _EJG_TIMER_HPP_ */

//
// $Log: timer.hpp,v $
// Revision 1.4.2.2  2009/07/20 12:52:10  graceej
// * Added main page to Doxygen documentation.
//
// Revision 1.4.2.1  2009/07/20 11:28:15  graceej
// * Build is clean on OS X and generates documentation.
//
// Revision 1.4  2009/07/20 10:21:53  graceej
// * Significant changes to avoid the assumption that clock tick types can be directly manipulated.
// * We now assume all clock differences can be stored as doubles.
// * This clearly needs review and thought.
//
// Revision 1.3  2009/07/20 09:07:45  graceej
// * Added undefs to prevent errors when compiling under Windows.
// * Carried out explicit static cast.
// * Addded missing include.
//
// Revision 1.2  2009/07/18 14:26:56  graceej
// * Weeded the code to smarten up its layout and remove unwanted functions.
// * Brought over these changes to the HEAD branch.
// * Prepare for upload of timer to boost vault.
//
// Revision 1.1.2.3  2009/07/18 12:37:23  graceej
// * Rationalised classes and names.
//
// Revision 1.1.2.2  2009/07/17 18:36:36  graceej
// * Include example in documentation.
//
// Revision 1.1.2.1  2009/07/17 18:21:12  graceej
// * Reorganised code so that the directory structure matches the namespace structure.
//
// Revision 1.34.2.2  2009/07/17 16:45:05  graceej
// * Documentation nearly complete.
//
// Revision 1.34.2.1  2009/07/17 14:01:50  graceej
// * Moved essential functions and documented them.
//
// Revision 1.34  2009/07/17 09:21:44  graceej
// * Checkin before refactoring.
//
// Revision 1.33  2009/07/16 21:38:02  graceej
// * Commit before refactoring and tidying code.
//
