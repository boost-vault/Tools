#include <iostream>
#include <cstdlib>


// Generate a list of lengths.  These are used as the number of
// iterations to time the kernel over.  They are (approximately)
// uniformly random between 1 and 300.  
int main() {
  // We want 10,000 trials in order to observe reasonably indicative
  // behaviour.
  unsigned list_length(10000);
  for (;list_length;list_length--, 
	 std::cout 
	 << 1+std::rand()%300 
	 << std::endl);
  return 0;
}
