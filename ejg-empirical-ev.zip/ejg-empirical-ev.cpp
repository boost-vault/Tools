#ifdef max
#undef max
#endif
#ifdef min
#undef min
#endif

#include "cycle.h"
#include <iostream>
#include <cmath>
#include <vector>
#include <algorithm>

void function_fast();
//void function_slow();



int main() {
  // We read in the number of iterations to measure over.
  unsigned max_average;
  std::cin >> max_average;
  max_average++; 
  ticks t0,t1;
  double dt;
  // We are going to take 4001 measurements of the function (odd so
  // the median is trivial and unique), then we are going to report
  // the minimum and median times.
  std::vector<double> times(4001);

  for (unsigned it(0); 
       it<times.size(); 
       ++it) {
    t0=getticks();
    for (unsigned it2(0); it2<max_average; ++it2,  
	   function_fast());
    t1=getticks();
    times[it] = elapsed(t1,t0);
  }
  // Now sort and pull out the minimum and median times.
  std::sort(times.begin(),times.end());
  std::cout << max_average << " " 
	    << times[0]/double(max_average) << " " 
	    << times[times.size()/2]/double(max_average) << std::endl;
}


/** 
 * Global variables used by the trivial kernel to prevent removal
 * through optimisation of what we wish to time
 */
unsigned sum(0);
unsigned prod(1);

/** 
 * @brief This is the simple kernel we wish to time. 
 * 
 * @param trivial_kernel_count The number of iterations of the loop.
 */
inline void trivial_kernel(unsigned trivial_kernel_count) {
  /* This prevents the optimizer skipping the loop as it forces side
     effects. */
  sum = 0; prod = 1;
  for (unsigned n(0); n != trivial_kernel_count; ++n) {
    sum += n; prod *= n/100;
  }
}

void function_fast() {
  trivial_kernel(1000); /* Should be around 0.5% faster than b. */
}
//void function_slow() {
//  trivial_kernel(1005); 
//}
